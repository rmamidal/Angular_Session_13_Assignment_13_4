var Redis = require('ioredis');
import * as environment from '../../environment.json';
import * as apiController from '../controller/apiController';

var isRedisConnected = false;
//create a redis client
if((<any>environment).redisConfig.length >1){
    var redisClient = new Redis.Cluster((<any>environment).redisConfig,{
        clusterRetryStrategy: 2000
    });
}
else{
    var redisClient = new Redis({
        host: (<any>environment).redisConfig[0].host,
        port: (<any>environment).redisConfig[0].port,
        retryStrategy: 2000
    });
}

/**
 * Connect to redis db
 */
redisClient.on('connect', function() {
    isRedisConnected = true;
    console.log('connected to Redis DB');
});
/**
 * If connection failure
 */
redisClient.on('error', function(err) {
    isRedisConnected = false;
    console.log('Redis Connection Error: ' + err);
});
/**
 * Read cache data from Redis
 * @param req 
 * @param res 
 * @param next 
 */
export let readFromCache = (req, res) => {
    if(isRedisConnected){
        redisClient.get(req.url, function (err, data) {
            if(err) apiController.getApi(req,res);
            if (data != null) {
                return res.status(200).send(data);
            } else {
                apiController.getApi(req,res);
            }
        });
    }
    else{
        apiController.getApi(req,res);
    }
}
  
/**
 * write data into redis
 * @param data 
 * @param req 
 * @param res 
 * @param next 
 */
export let writeToCache = (data, req, res) => {
    if(isRedisConnected){
        redisClient.set(req.url,data,function(error,result){
            if (error) console.log("Redis Error while writing data "+error);
        });
    }
}