
import * as environment from '../../environment.json';
import * as redisController from '../controller/redisController';

var request = require('request');

/**
 * External Drupal API calls with authentication
 * @param req 
 * @param res 
 * @param next 
 */
export let getApi = (req,res) => {
    let options = generateOptions(req,res);
    request(options, function(error, response, body){
        if (error) return res.status(500).send({message: error.message});
        //to write data into redis database
        if((<any>environment).isRedisCacheEnabled){
            redisController.writeToCache(body,req,res);
        }
        return res.status(response.statusCode).send(body);
    });    
};

/**
 * Method to generate options
 * @param req 
 * @param res 
 */
export let generateOptions = (req,res) => {
    var urlData = (<any>environment).apiUrl+req.url;
    var auth = "Basic " + new Buffer((<any>environment).userName + ":" + (<any>environment).pwd).toString("base64");
    //console.log(urlData);
    const options = {
        url: urlData,
        method: 'GET',
        rejectUnauthorized: false,
        requestCert: false,
        headers: {
            'Content-Type':'application/hal+json',
            'Authorization' : auth  
        }
    };
    return options;
};

/**
 * Post Data into API Gateway
 * @param req 
 * @param res 
 */
export let postData = (req,res) => {
    let options = generateOptionsForPost(req,res);
    request(options, function(error, response, body){
        if (error) return res.status(500).send({message: error.message});
        //to write data into redis database
        //redisController.writeToCache(body,req,res,next);
        res.status(response.statusCode).send(body);
    }); 
};
/**
 * Generate options for API Gateway
 * @param req 
 * @param res 
 */
export let generateOptionsForPost = (req,res) => {
    var auth = "Basic " + new Buffer((<any>environment).apiGateWayUserName+ ":" +(<any>environment).apiGateWayPassword).toString("base64");
    var urlData = (<any>environment).apiGateWayUrl+req.url;
    let bodyData = JSON.stringify(req.body);
    const options = {
      url: urlData,
      method: 'POST',
      rejectUnauthorized: false,
      requestCert: false,
      headers: {
        'Content-Type':'application/json',
        'Authorization' : auth,
        'Accept': 'application/json'  
      },
      body : bodyData
    };
    return options;
};

//Estore api.
 /**
 * External Drupal API calls with authentication
 * @param req 
 * @param res 
 * @param next 
 */
export let getEstoreApi = (req,res) => {
    let options = generateEstoreOptions(req,res);
    request(options, function(error, response, body){
        if (error) return res.status(500).send({message: error.message});
        //to write data into redis database
        if((<any>environment).isRedisCacheEnabled){
            redisController.writeToCache(body,req,res);
        }
        return res.status(response.statusCode).send(body);
    });    
};

/**
 * Method to generate options
 * @param req 
 * @param res 
 */
export let generateEstoreOptions = (req,res) => {
    var urlData = (<any>environment).eStoreUrl+req.url;
    var auth = "Bearer " + (<any>environment).eStoreToken;
    //console.log(urlData);
    const options = {
        url: urlData,
        method: 'GET',
        rejectUnauthorized: false,
        requestCert: false,
        headers: {
            'Content-Type':'application/hal+json',
            'Authorization' : auth  
        }
    };
    return options;
};

/**
 * Post Data into API Gateway
 * @param req 
 * @param res 
 */
export let postEstoreData = (req,res) => {
    let options = generateEstoreOptionsForPost(req,res);
    request(options, function(error, response, body){
        if (error) return res.status(500).send({message: error.message});
        //to write data into redis database
        //redisController.writeToCache(body,req,res,next);
        res.status(response.statusCode).send(body);
    }); 
};
/**
 * Generate options for API Gateway
 * @param req 
 * @param res 
 */
export let generateEstoreOptionsForPost = (req,res) => {
    var urlData = (<any>environment).eStoreUrl+req.url;
    var auth = "Bearer " + (<any>environment).eStoreToken;
    //console.log(urlData);
    const options = {
        url: urlData,
        method: 'POST',
        rejectUnauthorized: false,
        requestCert: false,
        headers: {
            'Content-Type':'application/hal+json',
            'Authorization' : auth
        },
    };
    return options;
};

export let getDrupalSession = (req,res) => {
    let options = generateOptionsForDrupalToken(req,res);
    request(options, function(error, response, body){
        if (error) return res.status(500).send({message: error.message});
        //to write data into redis database
        //redisController.writeToCache(body,req,res,next);
        res.status(response.statusCode).json(body);
    }); 
}

export let generateOptionsForDrupalToken = (req,res) => {
    const options = {
        url: (<any>environment).apiUrl+'/session/token',
        method: 'GET',
        rejectUnauthorized: false,
        requestCert: false
          
    };
    return options;
};

export let postDataToDrupal = (req,res) => {
    let options = generateOptionsForDrupalPost(req,res);
    request(options, function(error, response, body){
        if (error) return res.status(500).send({message: error.message});
        //to write data into redis database
        //redisController.writeToCache(body,req,res,next);
        res.status(response.statusCode).send(body);
    }); 
};

export let generateOptionsForDrupalPost = (req,res) => {
    var data = req.body;
    var auth = "Basic " + new Buffer((<any>environment).userName + ":" + (<any>environment).pwd).toString("base64");
    var urlData = (<any>environment).apiUrl+req.url;
    const options = {
      url: urlData,
      method: 'POST',
      rejectUnauthorized: false,
      requestCert: false,
      headers: {
        'Content-Type':'application/json',
        'Authorization' : auth,
        'X-CSRF': req.headers['x-csrf']  
      },
      body :JSON.stringify(data)     
    };
    return options;
};
