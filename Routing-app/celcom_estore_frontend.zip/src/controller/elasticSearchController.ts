import * as environment from '../../environment.json';

const elasticsearch = require('elasticsearch');
const request = require('request');

/**
 * Method to get elastic search data using request module
 * @param req 
 * @param res 
 */
export let getSearchData = (req,res) => {
  var options ={
    url: (<any>environment).elasticSearchUrl+':9200'+req.url,
    //url: 'http://localhost:9200'+req.url,
    method: 'GET'
  };
  request(options, function(error, response, body){
    if (error) return res.status(500).send({message: error.message});
    res.status(response.statusCode).send(getFormattedResponse(body));
  });
};

/**
 * Method to format the elastic search response
 * @param dataset 
 */
export let getFormattedResponse = (dataset) => {
  /**
   * Creating an interface to handle dynamic object data
   */
  interface Object {
    [key: string]: any
  }

  var response: Object = {};
  var formattedData = new Array();
  let responseData = JSON.parse(dataset);
  response.total = responseData.hits.total;
  for (var i = 0; i< responseData.hits.hits.length; i++) {
	  var res = new Object();
    var data = responseData.hits.hits;
    //Since object.entries is not supported in node js (workaround need to fix)
    //for (let [key, value] of Object.entries(data[i]._source)) {
      //res[key] = value[0];
    //}
    Object.keys(data[i]._source).forEach(function(key,index) {
      res[key] = data[i]._source[key][0];
    });
    formattedData.push(res);
  }
  response.data = formattedData;
  //console.log(response);
  return response;
}; 

export let pingElasticSearchServer = (req,res) => {
    let esClient = createElasticSearchClient();
    
    esClient.ping({
        // ping usually has a 3000ms timeout
        requestTimeout: 3000
      }, function (error) {
        if (error) {
          console.trace(error);
        } else {
          console.log('All is well');
        }
      });
};

export let createElasticSearchClient = () => {
    const esClient = new elasticsearch.Client({
        host: (<any>environment).apiUrl+':9200',
        log: 'error'
    });
    return esClient;
};