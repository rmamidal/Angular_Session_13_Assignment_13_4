// import {StarRatingComponent} from '../App/Widget/StarRating/starrating.component'
// import {FooterBannerComponent} from '../App/Widget/FooterBanner/footerbanner.component';
// import {CallOutIconComponent} from '../App/Widget/call-out-icon/call-out-icon.component';
// import {IconLayoutComponent} from '../App/Widget/IconLayout/iconlayout.component';
export const AppComponentList =[
]
// export const AppComponentList =[
//     {
//         Name:"StarRating",
//         Key:"starRating",
//         component:StarRatingComponent
//     },
//     {
//         Name:"Callout",
//         Key:"callout",
//         component:CallOutIconComponent
//     },
//     {
//         Name:"FooterBanner",
//         Key:"footerBanner",
//         component:FooterBannerComponent        
//     },
//     {
//         Name:"IconLayout",
//         Key:"iconLayout",
//         component:IconLayoutComponent
//     }   
// ]