import {AddWidget} from './Model/addwidget.model';
import {ContentNavigation} from './Model/contentnavigation.model'
import * as environment from '../../environment.json';

export class BaseComponent {
    public ApiUrl:string=(<any>environment).nodeUrl;
    private TemplateType:string;
    public IsXpax:boolean=false;    
    private APP_TEMPLATE_TYPE:string = "TemplateType";
    private TEMPLATE_DEFAULT:string = "default";
    private TEMPLATE_XPAX:string = "xpax";
    constructor(){        
        this.InitBase();
    } 
    
    private InitBase(){        
        if (typeof window !== 'undefined') {
            let templateType = localStorage.getItem(this.APP_TEMPLATE_TYPE);
            if(templateType!=null){
                if(templateType == this.TEMPLATE_XPAX){
                    this.IsXpax = true;
                    this.TemplateType = templateType;
                }
                else{
                    this.IsXpax = false;
                    this.TemplateType = templateType;
                }
            }
        }
    }


    public defaultOnClick(){
        return false;
    } 
}