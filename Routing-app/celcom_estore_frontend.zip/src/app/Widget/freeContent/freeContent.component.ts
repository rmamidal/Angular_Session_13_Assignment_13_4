import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { FreeContentService } from "./freeContent.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'
import {DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';

@Component({
  selector: 'app-freecontent',
  templateUrl: './freeContent.component.html',
  styleUrls: ['./freeContent.component.css'],
  providers:[ RedirectionService, FreeContentService ]
})

export class FreeContentComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public FreeContentResponse;
	constructor(private _service:FreeContentService,private sanitizer: DomSanitizer) {
    super();
	}

	ngOnInit() {		    
    this.Init();
	}
  
  private Init() {    
      if(this.data && this.data.Api != undefined){
        let apiUrl = "/" + this.data.Api + "?_format=hal_json";
        this._service.Find(apiUrl).subscribe(
          (response)=>{
            this.FreeContentResponse = this.sanitizer.bypassSecurityTrustHtml(response['Items'][0].body);
          });
      }
  }
}