import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { VideoBannerService } from "./video-banner.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'
import {DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';

@Component({
  selector: 'app-video-banner',
  templateUrl: './video-banner.component.html',
  styleUrls: ['./video-banner.component.css'],
  providers:[ RedirectionService, VideoBannerService ]
})
export class VideoBannerComponent extends BaseComponent implements OnInit {
  public player: any;
	public src: SafeResourceUrl;
  @Input() data: any;

	@Input() width = 640;
	@Input() height = 390;
	@Input() videoUrl: string = "";
  @Input() playerId: string = "playerId_1";
  public VideoBannerResponse = null;

	constructor(private sanitizer: DomSanitizer, private _service:VideoBannerService) {
    super();
	}

	ngOnInit() {		    
    this.Init();
	}
  
  private Init() {
      if(this.data && this.data.Api != undefined){
        let apiUrl = "/" + this.data.Api + "?_format=hal_json";
        this._service.Find(apiUrl).subscribe(
          (response)=>{            
            this.VideoBannerResponse = response['Items'][0];
            this.videoUrl = this.VideoBannerResponse.Video;            
            if (this.videoUrl !== '') {              
              this.EmbedVideo(this.videoUrl);
            }
          });
      }
  }

  private EmbedVideo(videoUrl:string){    
    let embedUrlId = this.getIdFromURL(videoUrl);
    this.src = this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/' +
    embedUrlId + '?enablejsapi=1');
  }

  private getIdFromURL(url: string) {    		
		const regex = /https?:\/\/(?:[0-9A-Z-]+\.)?(?:youtu\.be\/|youtube(?:-nocookie)?\.com\S*?[^\w\s-])([\w-]{11})(?=[^\w-]|$)(?![?=&+%\w.-]*(?:['"][^<>]*>|<\/a>))[?=&+%\w.-]*/ig; // tslint:disable-line

		function contains(str: string, substr: string) {
			return (str.indexOf(substr) > -1);
		}

		let id = url.replace(regex, '$1');

		if (contains(id, ';')) {
			const pieces = id.split(';');

			if (contains(pieces[1], '%')) {
				const uriComponent = decodeURIComponent(id.split(';')[1]);
				id = ('http://youtube.com' + uriComponent)
					.replace(regex, '$1');
			} else {
				id = pieces[0];
			}
		} else if (contains(id, '#')) {
			id = id.split('#')[0];
		}

		return id;
	}
}