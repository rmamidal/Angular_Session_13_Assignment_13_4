export interface Options {
	openAllOnInit: boolean,
	// openByHash: false,
	// openIndex: null,
	openOnViewports: string[], // array: viewport names - eg.: ['mobile', 'tablet', 'desktop-small', 'desktop']
	// removeStyles: false,
	singleOpen: boolean
	// tabMode: false,
	// unresolvedClass: 'is-unresolved',
}
