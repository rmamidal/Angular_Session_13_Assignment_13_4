import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Http, RequestOptionsArgs, RequestOptions, Headers } from "@angular/http";
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { RoiRetailService } from './roi-retail.service';
import { BaseComponent } from '../../base.component';
import * as environment from '../../../../environment.json';

@Component({
	selector: 'retail-roi',
	templateUrl: './roi-retail.component.html',
	styleUrls: ['./roi-retail.component.css', '../../../assets/css/bootstrap.min.css', '../../../assets/css/google-fonts.css'],
	providers: [RoiRetailService]
})
export class RoiRetailComponent extends BaseComponent implements OnInit {
	@ViewChild('retailForm') roiRetailForm: NgForm;
	@Input() data: any;
	public submitURL = (<any>environment).roiFormSubmission;
	public IsSuccess: boolean = false;
	temp: any;
	model: Object;
	modelLabels: Object;
	selectValue: number = 0;
	submitted = false;
	navs = ['NEW NRIC', 'OLD NRIC', 'PASSPORT', 'MILITARY', 'POLICE'];
	fileNames: string;
	
	constructor(private _http:Http,private _service: RoiRetailService) {
		super();
		this.model = {
			"natureOfBusiness": "",
			"interestedIn": "",
			"id": "",
			"state": "",
			"email": "",
			"preferredContactMethod": "E-mail",
			"customerName": "",
			"idType": "",
			"category": "Retail",
			"mobileNo": "",
			"alternateContact": "",
			"source": "Portal",
			"installerName": "Installer Name",
			"comments": "",
			"postalCode": "",
			"town": "",
			"type": "",
			"country": ""
		};
		this.temp = {
			name: '',
			mob: null,
			email: '',
			prefcontact: 'E-mail',
			identype: "",
			id: null,
			desc: '',
			attachment: [],
			altermob: null
		};
		this.modelLabels = {
			formHead: "How can we help you today?",
			formDescription: "We’re listening. Tell us exactly what you need and you'll hear from us within 72 hours.",
			name: "Full name",
			nameDesc: 'Enter your name',
			nameValidationError: 'Please enter a value',
			email: "Email Address",
			emailDesc: "Enter your email",
			emailEmptyError: 'Please enter a value',
			emailValidationError: 'Please enter valid email ID',
			mob: "Mobile Number",
			mobDesc: 'eg. +60 12345678',
			mobEmptyError: 'Please enter a value',
			mobLengthError: 'Please enter a value in range 7-12 digits',
			mobValidationError: 'Please enter valid number',
			altMob: "Alternative Number",
			idType: "Identity Type",
			idNo: "ID No.",
			chooseIdType: 'Choose identity type',
			idNum: "ID Number",
			idValidationError: 'Please enter a value',
			pref: "Preferred contact method",
			prefEmail: "E-mail",
			prefMobile: "Call",
			desc: "Description Box",
			descOther: "(maximum 1500 characters)",
			attachment: "Attachments (Max 2 MB)",
			submit: 'Submit',
			validError: "Validation error"
		};
	}

	ngOnInit() {
		//this.init();
	}
		notificationPopup(createActivityResp) {
		if(typeof document !== undefined){
			var modal = document.getElementById('sucessModal');
			var p=document.getElementById('activityId');
			var data=createActivityResp.createActivityResp.activityId;
			p.innerHTML=data;
			modal.style.display = "block";
		  }		
	}

	onChangeFile(event: any) {
		let files = [].slice.call(event.target.files);
		this.fileNames = files.map(f => f.name).join(', ');
	}

	onSubmit(retailForm:NgForm) {
		this.submitted = true;
		this._service.PostROIFormData(retailForm.value)
		.subscribe(
			// Successful responses call the first callback.
			data => {	

			  let createActivityResp=data;
			  this.notificationPopup(createActivityResp);      			  
			},			
			// Errors will call this callback instead:
			err => {			  
			  console.log('Something went wrong!');
			}
		  ); 
	}
	changetextbox() {
		this.selectValue = 1;
	}
		
}
	
	