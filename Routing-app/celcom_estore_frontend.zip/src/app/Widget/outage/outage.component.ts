import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {OutageService} from "./outage.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';

@Component({
  selector: 'app-outage',
  templateUrl: './outage.component.html',
  styleUrls: ['./outage.component.css'],
  providers: [OutageService]
})
export class OutageComponent implements OnInit {
  @Input() data: any;
  public OutageResponse = null;

  constructor(private outageservice: OutageService) { }

  ngOnInit(){
    this.Init();
  }

  private Init() {    
    this.OutageResponse = this.data;
  }
}

