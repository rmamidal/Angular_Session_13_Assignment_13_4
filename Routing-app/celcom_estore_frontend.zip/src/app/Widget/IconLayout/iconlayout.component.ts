import { Component,OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {IconLayoutService} from "./iconlayout.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'



@Component({
  selector: 'iconlayout-component',
  templateUrl: './iconlayout.component.html',
  styleUrls: ['./iconlayout.css'],
  providers: [IconLayoutService,RedirectionService]
})

export class IconLayoutComponent{
    @Input() data: any;
    public IconLayoutResponse=null;
    IconDetailClass:string;
    IconRowClass:string;

    constructor(private iconlayoutservice: IconLayoutService,
      private _router:Router,
      private _activatedRoute:ActivatedRoute,
      private _redirectionService:RedirectionService

    ){
    }

    ngOnInit() {
      this.Init();
    }

    public ManageContentNavigation(data:any){
       let obj= new ContentNavigation().ManagePageRedirection(data);
       this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);
    }
    private Init() {
      if(this.data && this.data.Api != undefined){
        let url = "/"+ this.data.Api + "?_format=hal_json";
        this.iconlayoutservice.Find(url).subscribe(
          (response:any)=>{
            if(response.Items.length > 0) {
              this.IconLayoutResponse = response.Items[0];
              // Icon Detail Count
              let IconCount = this.IconLayoutResponse.IconDetail.length;
              if(IconCount == 5 || IconCount == 3) {
                this.IconDetailClass = 'is-col-tablet-p-4';
                this.IconRowClass = 'is-justify-content-center';
              }
              else {
                this.IconDetailClass = 'is-col-tablet-p-3';
              }
              if(this.IconLayoutResponse.ButtonText.trim() != '') {
                this.IconLayoutResponse.SetDisplay = "inline-block";
              }
              else {
                this.IconLayoutResponse.SetDisplay = "none";
              };
            }
          });
        }
    }
}