import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { SearchResultService } from "./searchresult.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model';
import {ElasticSearchRequestModel} from '../../Model/elasticsearch.model';
import {RedirectionService} from '../../Service/redirection.service';
import { elasticSearchService } from './elasticsearch.service';

@Component({
  selector: 'searchresult-component',
  templateUrl: './searchresult.component.html',
  providers:[elasticSearchService, RedirectionService, SearchResultService]
})
export class searchresultComponent extends BaseComponent implements AppWidgetComponent {
  @Input() data: any;
  public SearchResultResponse = [];  
  //public SearchResultTitle:string=null;
  public SearchResultIsEmpty:boolean = false;
  public SearchResultDynamicURL = null;
  public SearchResultTotal = null;
  public SearchKeyword = null;
  public NoMoreResults = null;  
  public SearchResultFirstPage = 0;
  public IsDisplayLoadMore:boolean = false;
  public RequestParameter = new ElasticSearchRequestModel();
    constructor(private _elasticSearchService:elasticSearchService,
      private _SearchResultService:SearchResultService,
      private _redirectionService:RedirectionService,
      private _activatedRoute:ActivatedRoute,
      private _router:Router           
    ){
      super();
    }

    ngOnInit(){ 
      this.Init();
    }

    private Init() {
      let pageIndex = 0;   
      this.Bind(pageIndex);
    }

    private Bind(pageIndex:number){
      let SearchKeyFromStorage = '';
      if (typeof window !== 'undefined') {
        SearchKeyFromStorage = localStorage.getItem('searchKey');
      }
      if(SearchKeyFromStorage!=undefined){
        this.RequestParameter.SearchTerm = SearchKeyFromStorage;
      this.RequestParameter.PageIndex = pageIndex; 
      this.SearchKeyword = this.RequestParameter.SearchTerm;
      this._elasticSearchService.Search('/_search', this.RequestParameter).subscribe(
        (response)=>{          
          if(response.data.length>0){
            this.SearchResultTotal = response.total;
            if(this.SearchResultTotal<10){
              this.SearchResultFirstPage=this.SearchResultTotal;
              this.IsDisplayLoadMore = false;
            }else{
              this.SearchResultFirstPage= this.SearchResultFirstPage + response.data.length;
              if(this.SearchResultFirstPage == this.SearchResultTotal){
                this.IsDisplayLoadMore = false;
              }else{
                this.IsDisplayLoadMore = true;
              }
            }   
            response.data.forEach((item:any) => {
              this.SearchResultResponse.push(item);
              if("undefined" === typeof(item["field_textfield_title"])){
                item["SearchResultTitle"]=item.title;
              }else{
                item["SearchResultTitle"]=item.field_textfield_title;
              }
            });                                
          }
          else
          {
            //diplay message : No Records Found..
            this.IsDisplayLoadMore = false;
            this.SearchResultIsEmpty = true;
              }               
        });
      }
    }

  public LoadMore(){  
    this.RequestParameter.PageIndex = this.RequestParameter.PageIndex + this.RequestParameter.PageSize;
    this.Bind(this.RequestParameter.PageIndex);
  }

  public ManageContentNavigation(data:any){   
      let obj= new ContentNavigation().ManagePageRedirection(data);
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
      
}