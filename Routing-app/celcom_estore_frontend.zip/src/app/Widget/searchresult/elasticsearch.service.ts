import {Injectable} from '@angular/core';
import {Http, RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../../base.service';
import {AppService} from '../../Service/app.service';
import {ElasticSearchRequestModel} from '../../Model/elasticsearch.model'

@Injectable()
export class elasticSearchService extends BaseService  {
    constructor(private _service:AppService){
        super();
    }  
    public Search(apiURL:string, requestParameters:ElasticSearchRequestModel):Observable<any>{
        //let options = this.GenerateHeader();
         return this._service 
         .getElasticSearch(apiURL, requestParameters)
         .map((response:any)=>{
            return response;
        });
        
    }
 } 