import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Http, RequestOptionsArgs, RequestOptions, Headers } from "@angular/http";
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { RoiBusinessService } from './roi-business.service';
import { BaseComponent } from '../../base.component';
import * as environment from '../../../../environment.json';

@Component({
	selector: 'business-roi-form',
	templateUrl: './business-roi-form.component.html',
	styleUrls: ['./business-roi-form.component.css', '../../../assets/css/bootstrap.min.css', '../../../assets/css/google-fonts.css'],
	providers: [RoiBusinessService]
})
export class BusinessRoiFormComponent extends BaseComponent implements OnInit {
	@ViewChild('retailForm') roiRetailForm: NgForm;
	@Input() data: any;
	public submitURL = (<any>environment).roiFormSubmission;
	public IsSuccess: boolean = false;
	temp: any;
	model: Object;
	modelLabels: Object;
	selectValue: number = 0;
	fileNames: string;

	constructor(private _http:Http, private _service:RoiBusinessService) {
		super();
	//	this.states = ['KUALA LUMPUR', 'SELANGOR', 'CYBERJAYA', 'PUTRAJAYA', 'WILAYAH PERSEKUTUAN', 'PAHANG', 'PERAK', 'KELANTAN', 'TERENGGANU', 'KEDAH', 'PENANG', 'PERLIS', 'PULAU PINANG', 'SABAH', 'SARAWAK', 'JOHOR', 'MELAKA', 'NEGERI SEMBILAN'];
		this.model = { businesstype: '', state: '',  email: '', prefcontact: true, desc: '', attachment: '', identype: '', id: ''};
		this.modelLabels = {
			'formHead': "How can we help you today?",
			'formDescription':'Business should always be zooming along. Tell us exactly what you need and you will hear from us within 72 hours.',
			'name': "Full name",
			'nameDesc': 'Enter your name',
			'nameValidationError': 'Please enter a value',
			'companyName': "Company name",
			'companyDesc': 'Enter Company name',
			'companyValidationError': 'Please enter a value',
			'mob': "Mobile Number",
			'mobDesc': 'eg. +60 12345678',
			'mobEmptyError': 'Please enter a value',
			'mobLengthError': 'Please enter a value in range 7-12 digits',
			'mobValidationError': 'Please enter valid number',
			'altMob': "Alternative Number",
			'stateDesc': 'State',
			'email': "Email Address", 
			'emailDesc': "Enter your email",
			'emailEmptyError': 'Please enter a value',
			'emailValidationError': 'Please enter valid email ID',
			'businessType': "Nature of business", 
			'businessregistRationDesc': 'Enter business registration',
			'businessTypeError': 'Please enter a value',
			'idType': "Identity Type",
			'choosebusinessType': 'Choose business type',
			'chooseIdType': 'Choose ID type',
			'idNum': "ID Number", 
			'pref': "Preferred contact method", 
			'prefEmail': "Email",
			'prefMobile': "Mobile",
			'desc': "Description/Comments", 
			'descOther': "(maximum 1500 characters)", 
			'attachment': "Attachments (Max 2 MB)",
			'submit': 'Submit',
			'validError': "Validation error",
			'interestIn': "Interested in",
			'plans': "Plans",
			'solutions': "Solutions",
			'others': "Others"
		};
	};
	navs = ['Banking', 'Construction', 'Government Sector', 'GLC', 'ICT', 'Insurance', 'Logistic', 'Manufacturing', 'Oil & Gas', 'Services', 'SME', 'Trading', 'Transportation', 'Utilities', 'Others'];
	submitted = false;
	navsID = ['NEW NRIC','OLD NRIC','PASSPORT','MILITARY','POLICE'];
	//states =  ['KUALA LUMPUR', 'SELANGOR', 'CYBERJAYA', 'PUTRAJAYA', 'WILAYAH PERSEKUTUAN', 'PAHANG', 'PERAK', 'KELANTAN', 'TERENGGANU', 'KEDAH', 'PENANG', 'PERLIS', 'PULAU PINANG', 'SABAH', 'SARAWAK', 'JOHOR', 'MELAKA', 'NEGERI SEMBILAN'];
	states =  ['Cyberjaya/Putrajaya', 'Johor', 'Kedah', 'Kelantan', 'Melaka', 'Negeri Sembilan', 'Pahang', 'Perak', 'Perlis', 'Pulau Pinang', 'Sabah', 'Sarawak', 'Terengganu ', ' Kuala Lumpur', 'Labuan', 'Selangor'];
	
	ngOnInit() {
		//this.init();
	}

	notificationPopup(createActivityResp) {
		if(typeof document !== undefined){
			var modal = document.getElementById('sucessModal');
			var p=document.getElementById('activityId');
			var data=createActivityResp.createActivityResp.activityId;
			p.innerHTML=data;
			modal.style.display = "block";
		  }		
	}

	onChangeFile(event: any) {
		let files = [].slice.call(event.target.files);
		this.fileNames = files.map(f => f.name).join(', ');
	}

	onSubmit(retailForm:NgForm) {
		this.submitted = true;
		this._service.PostROIFormData(retailForm.value)
		.subscribe(
			// Successful responses call the first callback.
			data => {			  
			let createActivityResp=data;
			  this.notificationPopup(createActivityResp);  			  
			},			
			// Errors will call this callback instead:
			err => {			  
			  console.log('Something went wrong!');
			}
		  ); 
	}
	changetextbox() {
		this.selectValue = 1;
	}
		
}
	