import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseService } from '../../base.service';

@Injectable()
export class TableWithoutHeadingService extends BaseService{

  constructor(private _http: Http) {
    super();
  }
  public getData(): Observable<any[]>{
    let url = this.BaseUrl + "tablewithoutheading.json";
    return this._http.get(url).map((data)=>{return data.json();});
  }
}
