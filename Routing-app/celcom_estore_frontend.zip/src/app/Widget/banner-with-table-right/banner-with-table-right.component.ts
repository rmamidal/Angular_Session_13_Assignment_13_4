import { Component, OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BannerWithTableRightService} from "./banner-with-table-right.service";
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'app-banner-with-table-right',
  templateUrl: './banner-with-table-right.component.html',
  styleUrls: ['./banner-with-table-right.component.css'],
  providers: [BannerWithTableRightService, RedirectionService]
})
export class BannerWithTableRightComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  BannerWithTablerightBuyNowData :any;
  TableData:any;


  constructor(private _service:BannerWithTableRightService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService
  ){
    super();
  }

  ngOnInit(){
    this.Init();
  }

  private Init() {
    
    
    // this._service.FindBuyNowSectionForTableLeft(this.data.Api).subscribe(
    //   (response)=>{
    //    this.BannerWithTableleftBuyNowData = response['Items'][0];
    //    this.BannerWithTableleftBuyNowData.BannerImage = this.ApiUrl + this.BannerWithTableleftBuyNowData.BannerImage;
    //    this.BannerWithTableleftBuyNowData.ForegroundImage = this.ApiUrl + this.BannerWithTableleftBuyNowData.ForegroundImage;
    //    if(this.BannerWithTableleftBuyNowData.ButtonText != '') {
    //     this.BannerWithTableleftBuyNowData.SetDisplay = "block";
    //    }
    //    else {
    //     this.BannerWithTableleftBuyNowData.SetDisplay = "none";
    //    }
    //    this.TableData = this.BannerWithTableleftBuyNowData.TableData;
    
    if(this.data && this.data.Api != undefined){
      this._service.FindBuyNowSectionForTableRight(this.data.Api).subscribe(
        (response)=>{
        this.BannerWithTablerightBuyNowData = response['Items'][0];
        this.BannerWithTablerightBuyNowData.BannerImage = this.ApiUrl + this.BannerWithTablerightBuyNowData.BannerImage;
        this.BannerWithTablerightBuyNowData.ForegroundImage = this.ApiUrl + this.BannerWithTablerightBuyNowData.ForegroundImage;
        if(this.BannerWithTablerightBuyNowData.ButtonText != '') {
          this.BannerWithTablerightBuyNowData.SetDisplay = "block";
        }
        else {
          this.BannerWithTablerightBuyNowData.SetDisplay = "none";
        }
        this.TableData = this.BannerWithTablerightBuyNowData.TableData;
        });
    }
  }
  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
 }
}
