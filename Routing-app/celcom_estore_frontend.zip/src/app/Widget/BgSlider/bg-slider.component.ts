import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { AppService } from '../../Service/app.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'bg-slider',
  templateUrl: './bg-slider.component.html',
  styleUrls: ['./bg-slider.component.css']
})
export class BgSliderComponent implements OnInit {

  @Input() data: any;
  @Input() bgPattern: string;

  public currentSlide:number =0 ;
  public currentBackgroundImage:string;
  public currentBackgroundColor:string;
  public currentBackground :string;

  public carouselBanner: NguCarousel;
  public imageCOnfig: any;
  public accouncementObj: any = [];
  constructor(private appService: AppService, private sanitizer: DomSanitizer) {
  }

  getIconUrl(ev) {
    if (ev == 2) {
      return 'url(' + this.imageCOnfig.left + ')';
    } else {
      return 'url(' + this.imageCOnfig.right + ')';
    }
  }
  
  
  onMove($event){ 
    this.currentSlide = $event.currentSlide;  
  }
  
  getBackground() {
    var imgurl;

    switch (this.bgPattern) {
      case 'twoColGradPattern':
        imgurl = 'url(' + this.imageCOnfig.background + '),linear-gradient(77deg, #f76a0f, #af358f)';
        break;
      case 'solidColor':
        imgurl = '#fff;'
        break;
      case 'bgPattern':
        imgurl = ' url(' + this.imageCOnfig.background + ') no-repeat';
        break;
      case 'solColPattern':
        imgurl = 'url(' + this.imageCOnfig.background + ') no-repeat, blue';
        break;
      case 'twoColGradPattern':
        imgurl = 'url(' + this.imageCOnfig.background + '),linear-gradient(77deg, #f76a0f, #af358f)';
        break;
      default:
        imgurl = ' url(' + this.imageCOnfig.background + ') no-repeat';
    }

    return imgurl;
  }

  initializeWidget() {

    this.imageCOnfig = {
      'background': './assets/img/pattern-desktop.png',
      'right': './assets/img/next-button-RIGHT.png',
      'left': './assets/img/next-button-LEFT.png',
    }

    this.carouselBanner = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 400,
      interval: 4000,
      point: {
        visible: true,
        pointStyles: `
             .ngucarouselPoint {
               list-style-type: none;
               text-align: center;
               padding: 20px;
               margin: 0;
               white-space: nowrap;
               overflow: auto;
               position: absolute;
               width: 100%;
               bottom: 20px;
               left: 0;
               box-sizing: border-box;
             }
             .ngucarouselPoint li {
               display: inline-block;
               border-radius: 999px;
               background-color: rgba(128, 128, 128, 0.5);
               height:7px;
               width:7px;
               margin: 0 3px;
               transition: .4s ease all;
             }
             .ngucarouselPoint li.active {
              background-color: #009ade !important;
              height:8px;
              width:8px;   
                
             }
           `
      },
      load: 2,
      loop: false,
      touch: false
    }
  }


  private initializeData() {
    if (this.data && this.data.Api) {
      
    let url = "/"+ this.data.Api + "?_format=hal_json";  
      let isArray = Array.isArray(this.data.currentBackgroundImage);  
      if(!isArray){
        
        this.currentBackgroundColor = this.data.BackgroundColor ;
        this.currentBackgroundImage = this.data.BackgroundImage.Desktop.img;
        this.currentBackgroundImage = url + this.currentBackgroundImage;
        this.currentBackground  ='url(' + this.currentBackgroundImage + ') ';
        
      }      
      else{
        
        this.currentBackgroundColor = 'transparent';
        this.currentBackgroundImage = '/assets/img/pattern-desktop.png';
        this.currentBackgroundImage = url + this.currentBackgroundImage;
        this.currentBackground  ='url(' + this.currentBackgroundImage + ') ';
        
      }


      this.appService
        .get(url).subscribe((response: any) => {
          this.accouncementObj = response && response.Items ? response.Items : [];
          this.sanitizeData();  
        })
    }

  //  const dataList =  {"Items":[{"Title":"AM_Important Announcement","Description":"\u003Cp\u003EWork better and do work that matters. This is the place to grow and learn while no skills are wasted doing coffees and copy machine job. We bring smiles in making daily and distant communication\u00a0easier for people around. That\u0027s our passion.\u00a0\u003C\/p\u003E\n\n\u003Cp\u003E\u003Ca href=\u0022http:\/\/10.1.61.214\/ \u0022\u003EClick here\u003C\/a\u003E\u003C\/p\u003E","ButtonLink":"https:\/\/vpn.celcom.com.my\/Login\/Login\n","ButtonText":"Know More"},{"Title":"AM_Making difference at Celcom","Description":"\u003Cp\u003EWork better and do work that matters. This is the place to grow and learn while no skills are wasted doing coffees and copy machine job. We brings smiles in making daily and distant communication easier for people around. That\u0027s our passion.\u003C\/p\u003E","ButtonLink":"https:\/\/vpn.celcom.com.my\/Login\/Login\n","ButtonText":"Know More"},{"Title":"AM_Important_Announcement1","Description":"\u003Cp\u003E\u003Cem\u003E\u003Cstrong\u003EMAKING DIFFERENCE AT CELCOM !! \u003C\/strong\u003E\u003C\/em\u003EWhat is stopping you from joining Celcom? We love enthusiast like you! And in return you will get much more than just a 9 to 5 grind.\u003C\/p\u003E","ButtonLink":"http:\/\/www.google.com\n","ButtonText":"Hit me!"}],"Status":"200","StatusMessage":"SUCCESS"}
  //  this.accouncementObj = dataList.Items;
  //  this.sanitizeData(); 
  //  this.loadBackground(); 
  }


  sanitizeTextValue(textValue) {
    textValue = textValue || '';
    return textValue.replace(/\u00a0/g, ' ');
  }
  sanitizeData() {
    this.accouncementObj = this.accouncementObj.map((item) => {
      item.Title = this.sanitizer.bypassSecurityTrustHtml(this.sanitizeTextValue(item.Title));
      item.Description = this.sanitizer.bypassSecurityTrustHtml(this.sanitizeTextValue(item.Description));
      item.ButtonText = this.sanitizer.bypassSecurityTrustHtml(this.sanitizeTextValue(item.ButtonText));
      return item;
    })
  }
  ngOnInit() {
    this.initializeWidget();
    this.initializeData();
  }


}