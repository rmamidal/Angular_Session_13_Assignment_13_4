import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanBannerMegaComponent } from './plan-banner-mega.component';

describe('PlanBannerMegaComponent', () => {
  let component: PlanBannerMegaComponent;
  let fixture: ComponentFixture<PlanBannerMegaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanBannerMegaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanBannerMegaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
