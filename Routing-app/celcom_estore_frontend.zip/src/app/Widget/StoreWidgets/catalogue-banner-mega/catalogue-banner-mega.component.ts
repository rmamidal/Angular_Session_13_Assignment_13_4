import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { CatalogueBannerMegaService } from "./catalogue-banner-mega.service";
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'


@Component({
  selector: 'store-catalogue-banner-mega',
  templateUrl: './catalogue-banner-mega.component.html',
  styleUrls: ['./catalogue-banner-mega.component.css'],
  providers:[CatalogueBannerMegaService,RedirectionService]
})
export class CatalogueBannerMegaComponent extends BaseComponent implements OnInit {
	@Input() data: any;
	constructor(private catalogueBannerMegaService: CatalogueBannerMegaService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
	}

	ngOnInit() {

	}

	Init() {

	}

	public ManageContentNavigation(data:any){              
		let obj= new ContentNavigation().ManagePageRedirection(data);
		this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
	}

}
