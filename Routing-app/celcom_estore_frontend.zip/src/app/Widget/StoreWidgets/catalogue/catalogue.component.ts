import { Component, OnInit, ViewContainerRef,Input,Output,EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { CatalogueService } from "./catalogue.service";
import { CartService } from '../../../Service/cart.service';
import { CompareProductService } from '../../../Service/compareproduct.service';
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'


@Component({
  selector: 'store-catalogue',
  templateUrl: './catalogue.component.html',
  styleUrls: ['./catalogue.component.css'],
  providers:[CatalogueService,RedirectionService,CartService,CompareProductService]
})

export class CatalogueComponent extends BaseComponent implements OnInit {
	@Output() updateCompareItems:EventEmitter<any> = new EventEmitter();
	catalogueList = null;
	constructor(private catalogueService: CatalogueService,
		private cartService:CartService,
		private compProductService: CompareProductService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
	}

	ngOnInit() {
		this.Init();
	}

	Init() {
		let apiUrl:string = "/rest/V1/categories/6/products";      
		this.catalogueService.Find(apiUrl.trim()).subscribe(      
		(response: any)=>{  
				
			var resultData = response;
			resultData.forEach((item:any,index) => {
				item.price = 300;

				let url = '/rest/V1/products/' + item.sku;
				this.catalogueService.Find(url).subscribe(
				  (resp:any)=> {
					resp.custom_attributes.forEach((itemDetails:any) => {
						if (itemDetails.attribute_code == "most_popular") {
							item.mostpopular =  itemDetails.value;
						}
					});
				});
			});
			
			this.catalogueList = resultData; 
		});
	}

	addDeviceToCart(product:any) {
		this.cartService.addProductToCart(product,1);
		alert(product.sku+" added to cart");
	}
	public addToCompare(item:any) {
		this.compProductService.addProductToCompare(item);
		this.updateCompareItems.emit(item);
	}
	public ManageContentNavigation(data:any){              
		let obj= new ContentNavigation().ManagePageRedirection(data);
		this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
	}

}
