import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseService } from '../../../base.service';
import  {AppService} from '../../../Service/app.service';

@Injectable()
export class AddToCompareService extends BaseService {

	constructor(private _service:AppService) {
		super();
	}

  	public Find(apiURL:string):Observable<any[]> {  
      	let url = apiURL.replace(/[+_]/g,'%2B');
      	let options = this.GenerateHeader();    
      	return this._service
      	.get(url)
      	.map((response:any) => {
          return response
      	})        
  	} 
}
