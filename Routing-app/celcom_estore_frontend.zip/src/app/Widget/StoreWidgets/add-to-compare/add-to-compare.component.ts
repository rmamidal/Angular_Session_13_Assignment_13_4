import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { AddToCompareService } from "./add-to-compare.service";
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'
import { CompareProductService } from '../../../Service/compareproduct.service';
import { parse } from 'querystring';


@Component({
  selector: 'app-add-to-compare',
  templateUrl: './add-to-compare.component.html',
  styleUrls: ['./add-to-compare.component.css'],
  providers:[AddToCompareService,RedirectionService,CompareProductService]
})
export class AddToCompareComponent extends BaseComponent implements OnInit {
	public productsToCompare = null;

  constructor(private _service: AddToCompareService,
    private compProductService: CompareProductService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
	}

	ngOnInit() {
		this.Init();
	}

	Init() {
		this.productsToCompare = this.compProductService.retrieveProduct();
	/*	this.productsToCompare.forEach((itemParent:any,index) => { 
              // Providing the plan json
              let url2 = '/rest/V1/products/' + itemParent.sku;
              this._service.Find(url2).subscribe(
                (response:any)=> {
                  itemParent.KeyText = "RM " +response.price;
                  itemParent.custom_attributes = response.custom_attributes;
                  itemParent.custom_attributes.forEach((item:any) => {
                    switch(item.attribute_code) {
                      case "plan_data": 
                      itemParent.KeyFiguresText = item.value;
                      break;
                      case "knowmoretext": 
                        itemParent.knowMoreText = item.value;
                        break;
                      case "buynowtext": 
                        itemParent.BuynowText = item.value;
                        break;
                      case "indicatorclass": 
                        itemParent.IndicatorClass = 'is-level-' + item.value.toLowerCase();
                        break;
                      case "backgroundcolor": 
                        itemParent.BackgroundColor = 'is-bg-color-' + item.value;
                        break;
                      case "description": 
                        itemParent.TableInfo= item.value;
                        break;
                        case "url_key": 
                        itemParent.BuynowLink = 'store/plans/' + itemParent.sku;
                        break;
                    }
                  });
                });
  
              // Adding sample data which is not in Json output.
              itemParent.ProductText = itemParent.sku;
              //itemParent.TableInfo.innerHtml = itemParent.TableInfoUnformatted;
              itemParent.AtrHref="#rm-"+index;
            });

  */
}

removeCompareProduct(product:any) {
  this.compProductService.removeProductFromCompare(product);
  this.productsToCompare = this.compProductService.retrieveProduct();
}
removeAllCompareProducts() {
  this.compProductService.removeAllProductFromCompare();
  this.productsToCompare = this.compProductService.retrieveProduct();
}
	public ManageContentNavigation(data:any){              
		let obj= new ContentNavigation().ManagePageRedirection(data);
		this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
	}

}
