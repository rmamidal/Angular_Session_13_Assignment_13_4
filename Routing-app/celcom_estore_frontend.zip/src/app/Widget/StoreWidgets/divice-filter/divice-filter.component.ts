import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseComponent } from "../../../base.component";
import { DeviceFilterService } from './device-filter.service';

@Component({
  selector: 'app-divice-filter',
  templateUrl: './divice-filter.component.html',
  styleUrls: ['./divice-filter.component.css'],
  providers:[DeviceFilterService]
})
export class DiviceFilterComponent extends BaseComponent implements OnInit {
  filterSelectionForm:any = null;

  constructor(private deviceFilterService:DeviceFilterService) {
    super();
   }

  ngOnInit() {
    this.Init();
  }

  Init() {
    let apiURL:string = '/rest/V1/filterOptions/5';
    this.deviceFilterService.Find(apiURL.trim()).subscribe(
      (response:any) => {
        this.filterSelectionForm = response;
      }
    );
  }

   mob_filterBy() {
    document.getElementById("filter_dropdown").classList.toggle("is-filter-show");
    document.getElementById("mob_filterBy").classList.toggle("is-filter-active");
  }
  desk_filterBy() {
    if(document.getElementById("bundle_dropdown").classList.contains("is-filter-show")){
      document.getElementById("bundle_dropdown").classList.toggle("is-filter-show");
      document.getElementById("bundleBy").classList.toggle("is-filter-active");
    
    }
    if(document.getElementById("sortBy_dropdown").classList.contains("is-filter-show")){
      document.getElementById("sortBy_dropdown").classList.toggle("is-filter-show");
      document.getElementById("sortBy").classList.toggle("is-filter-active");
      
    }
    document.getElementById("filter_drop").classList.toggle("is-filter-show");
    document.getElementById("desk_filterBy").classList.toggle("is-filter-active");
  }
 }
