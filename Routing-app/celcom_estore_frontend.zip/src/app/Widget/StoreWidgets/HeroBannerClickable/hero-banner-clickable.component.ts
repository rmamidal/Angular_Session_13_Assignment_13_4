import { Component, OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {HeroBannerClickableService} from './hero-banner-clickable.service';
import {BaseComponent} from '../../../base.component';
//
import {ContentNavigation} from '../../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../../Service/redirection.service'

@Component({
  selector: 'store-hero-banner-clickable',
  templateUrl: './hero-banner-clickable.component.html',
  styleUrls: ['./hero-banner-clickable.component.css'],
  providers:[HeroBannerClickableService,RedirectionService]
})
export class HeroBannerClickableComponent extends BaseComponent implements OnInit {

  @Input() data: any;
  public HeroBannerImgClickResponse = null;
  BannerTextPresent: boolean;
  
  constructor(private heroBannerClickableService: HeroBannerClickableService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService
  ) { 
    super();
  }
  
  ngOnInit(){
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api != undefined){
      let url = "/"+ this.data.Api + "?_format=hal_json"; 
      this.heroBannerClickableService.Find(url).subscribe(
        (data:any)=>{  
          this.HeroBannerImgClickResponse = data.Items[0];
          if(this.HeroBannerImgClickResponse.BannerType == 'Text') {
            this.BannerTextPresent = true;
          }
          else {
            this.BannerTextPresent = false;
          }
          this.HeroBannerImgClickResponse.BannerImage = this.ApiUrl + this.HeroBannerImgClickResponse.BannerImage;
          this.HeroBannerImgClickResponse.MobileImage = this.ApiUrl + this.HeroBannerImgClickResponse.MobileImage;
        });
    }    
  }

  public ManageContentNavigation(data:any){                
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
}
