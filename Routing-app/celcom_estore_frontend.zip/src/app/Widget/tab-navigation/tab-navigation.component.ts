import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import "rxjs/add/operator/map";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'
import { Observable } from 'rxjs/Rx';

@Component({
  selector: 'app-tab-navigation',
  templateUrl: './tab-navigation.component.html',
  providers: [RedirectionService]
})

export class TabNavigationComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public TabNavigationResponse = null;
  public SelectedTab = null;
  public DataForActiveTab = null;  
  public IsInitializeImageCard:boolean=false;
  public IsInitializeImageCardOverlay:boolean=false;
  public IsInitializeTableComparison:boolean=false;
  public IsInitializeDetailBannerLeft:boolean=false;
  public IsInitializeDetailBannerRight:boolean=false;
  public IsInitializeFreeContent:boolean=false;

  public DataForImageCard =  null;
  public DataForImageCardOverlay =  null;
  public DataForTableComparison =  null;
  public DataForDetailBannerTextLeft =  null;
  public DataForDetailBannerTextRight =  null;  
  public DataForFreeContent =  null;  
  
  ComponentApi:string;

    constructor(private _router: Router,
      private _activatedRoute:ActivatedRoute,
      private _redirectionService:RedirectionService
    ){
        super();
    }

    ngOnInit(){
      this.Init();
    }

    private Init() {
      if(this.data){                    
        this.TabNavigationResponse = this.data.Tabs;
        this.SetActiveTab(0);        
      }
    }

    public OnTabSelect(item, index){
      this.ResetAllComponent();
      this.SetActiveTab(index);
      if(item.Data && item.Data.collections){
        this.ReInitializeSubComponent(item.Data.collections[0].Name);
      }
    }

    private SetActiveTab(selectedIndex) {
      let that = this;      
      that.TabNavigationResponse.forEach((item:any,index:number) => {        
        if(selectedIndex == index){          
          item.Data.collections.forEach((itemInner:any) => {                                 
            switch (itemInner.Name) {
              case "imageCard":
                that.DataForImageCard = itemInner;    
              break;
              case "tableComparison":
                that.DataForTableComparison = itemInner;
              break;
              case "imageCardOverlay":
                that.DataForImageCardOverlay = itemInner;
              break;
              case "detailBanner_left":
                that.DataForDetailBannerTextLeft = itemInner; 
              break;
              case "detailBanner_right":
                that.DataForDetailBannerTextRight = itemInner;
              break;
              case "freeContent":
                that.DataForFreeContent = itemInner;
              break;
            } 
            that.SelectedTab = that.TabNavigationResponse[selectedIndex].Title;
            that.ReInitializeSubComponent(itemInner.Name);       
          });
        }
      });
      
    }

    private ReInitializeSubComponent(subComponentName:string){
      switch (subComponentName) {
        case "imageCard":
          this.ReInitializeImageCardComponent(subComponentName);
        break;
        case "tableComparison":
          this.ReInitializeTableComparisonComponent(subComponentName);
        break;
         case "imageCardOverlay":
         this.ReInitializeImageCardOverlayComponent(subComponentName);
         break;
         case "detailBanner_left":
          this.ReInitializeDetailBannerLeftComponent(subComponentName);
         break;
         case "detailBanner_right":
          this.ReInitializeDetailBannerRightComponent(subComponentName);
         break;
         case "freeContent":
          this.ReInitializeFreeContentComponent(subComponentName);
        break;
      }      
    }

    private ReInitializeImageCardComponent(subComponentName){   
      setTimeout(()=>{              
        this.IsInitializeImageCard = false;
      },0)
      setTimeout(()=>{
        this.IsInitializeImageCard = true;        
      },0)
    }
 
    private ReInitializeTableComparisonComponent(subComponentName){     
      setTimeout(()=>{              
        this.IsInitializeTableComparison = false;
      },0)
      setTimeout(()=>{
        this.IsInitializeTableComparison = true;        
      },0)
    }

     private ReInitializeImageCardOverlayComponent(subComponentName){     
       setTimeout(()=>{              
         this.IsInitializeImageCardOverlay = false;
       },0)
       setTimeout(()=>{
         this.IsInitializeImageCardOverlay = true;         
       },0)
     }
     private ReInitializeDetailBannerLeftComponent(subComponentName){     
      setTimeout(()=>{              
        this.IsInitializeDetailBannerLeft = false;
      },0)
      setTimeout(()=>{
        this.IsInitializeDetailBannerLeft = true;        
      },0)
    }
    private ReInitializeDetailBannerRightComponent(subComponentName){     
      setTimeout(()=>{              
        this.IsInitializeDetailBannerRight = false;
      },0)
      setTimeout(()=>{
        this.IsInitializeDetailBannerRight = true;        
      },0)
    }
    private ReInitializeFreeContentComponent(subComponentName){     
      setTimeout(()=>{              
        this.IsInitializeFreeContent = false;
      },0)
      setTimeout(()=>{
        this.IsInitializeFreeContent = true;        
      },0)
    }

    private ResetAllComponent(){      
      this.IsInitializeImageCard = false;
      this.IsInitializeTableComparison = false;
      this.IsInitializeImageCardOverlay = false;      
      this.IsInitializeDetailBannerLeft = false;
      this.IsInitializeDetailBannerRight = false;
      this.IsInitializeFreeContent = false;
    }

    public ManageContentNavigation(data:any){
      let obj= new ContentNavigation().ManagePageRedirection(data);
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
   }
}
