import { Component,OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {ProductCardService} from "./productcard.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'productcard-component',
  templateUrl: './productcard.component.html',
  providers:[ProductCardService,RedirectionService]
})


export class ProductCardComponent extends BaseComponent implements AppWidgetComponent   {
  @Input() data: any;
  public ProductCardResponse = null;
  public ProductCardTextDisplay:string = "";
  public ProductCardClass:string = "";
  public ProductCardTextDisplayClass:string = "";
  public IsFlex:boolean= false;
  public BackgroundImage="";
  
  constructor(private productcardservice: ProductCardService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService
  ){
    super();
  }

  ngOnInit(){
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api !=undefined){
      let apiUrl:string = "/" + this.data.Api + "?_format=hal_json";       
      let isArray = Array.isArray(this.data.BackgroundImage);  
      if(isArray){
        //data not send for background image from CMS
        this.BackgroundImage = "";
      }
      else{
        this.BackgroundImage = this.data.BackgroundImage.Desktop.img;
        this.BackgroundImage = this.ApiUrl + this.BackgroundImage;
      }      
      
      this.ProductCardTextDisplay = this.data.TextDisplay;  
      this.productcardservice.Find(apiUrl.trim()).subscribe(      
          (response)=>{  
              this.ProductCardResponse = response['Items'];
              if(this.ProductCardTextDisplay == "left"){
                this.ManageLeftProductCard();
              }
              if(this.ProductCardTextDisplay == "center"){
                this.ManageCenterProductCard();
              }
              this.ProductCardResponse.forEach((item:any) => {
                if(item.BrandIcon !== ""){
                  item.BrandIcon = this.ApiUrl + item.BrandIcon;
                }
              });
          });
    }
  }
  public ManageContentNavigation(data:any){              
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
  private ManageLeftProductCard(){
    if(this.ProductCardResponse.length == 2 ){
      this.ProductCardTextDisplayClass = "u-grid-col is-col-mobile-p-12 is-col-tablet-p-6 is-equal-height";
      this.ProductCardClass = "default";
      this.IsFlex = false;
    }
    else {
      this.ProductCardTextDisplayClass = "u-grid-col is-col-mobile-p-12 is-col-tablet-p-4 is-equal-height";
      this.ProductCardClass = "default";
      this.IsFlex = true;
    }
  } 
  private ManageCenterProductCard(){
    if(this.ProductCardResponse.length == 2){
      this.ProductCardTextDisplayClass = "u-grid-col is-col-mobile-p-12 is-col-tablet-p-6 is-col-tablet-l-3 is-flex";
      this.ProductCardClass = "category";
      this.IsFlex = false;
    }else {
      this.ProductCardTextDisplayClass = "u-grid-col is-col-mobile-p-12 is-col-tablet-p-4 is-flex";
      this.ProductCardClass = "category";
      this.IsFlex = true;
    }
  } 
  // public defaultOnClick(){
  //   return false;
  // } 
}