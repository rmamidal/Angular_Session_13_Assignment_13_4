import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabRedirectionComponent } from './tab-redirection.component';

describe('TabNavigationComponent', () => {
  let component: TabRedirectionComponent;
  let fixture: ComponentFixture<TabRedirectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabRedirectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabRedirectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
