import { Injectable } from '@angular/core';
import { Http,RequestOptionsArgs, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseService } from '../../base.service';
import { AppService } from '../../Service/app.service';
@Injectable()
export class RoiDealerService extends BaseService {
  constructor(private _http: Http,private _service: AppService) {
      super();
  }


  public findRoiAuthToken():Observable<any[]>{ 
    let endPoint= '/getDrupalSessionToken';
      return this._service
       .get(endPoint)
       .map((response:any) => {           
           return response
       })       
   }

public submitDealerForm(token,dealerForm) {
 let body= JSON.stringify(dealerForm.value);
 let url = this.BaseUrl + '/email_rest_resource?_format=json'
 let _headers = new Headers();
 _headers.append('Content-Type','application/json');
 _headers.append('X-CSRF-Token',token);
 let options = new RequestOptions({ headers:_headers}); 

return this._http
   .post(url,body,options).map((res) => {
     res.json()
         
   })
  
}
private ApiEndPoint = '/email_rest_resource?_format=json';
public PostROIDealerFormData(token,dealerForm){      
let details = dealerForm.value;
  return this._service.postROI(this.ApiEndPoint,details,token);
}
  


}

