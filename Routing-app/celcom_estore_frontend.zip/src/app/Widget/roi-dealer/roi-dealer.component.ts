import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Http, RequestOptionsArgs, RequestOptions, Headers } from "@angular/http";
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { RoiDealerService } from './roi-dealer.service';
import { BaseComponent } from '../../base.component';
import * as environment from '../../../../environment.json';
import { BaseService } from '../../base.service';
import { AppService } from '../../Service/app.service';
@Component({
  selector: 'dealer-roi',
  templateUrl: './roi-dealer.component.html',
  styleUrls: ['./roi-dealer.component.css', '../../../assets/css/bootstrap.min.css', '../../../assets/css/google-fonts.css'],
  providers: [RoiDealerService]
})
export class RoiDealerComponent {
  model: Object;
  modelLabels: Object;
  selectValue: number = 0;
  @Input() data: any;
  token: any;
  msg: string;
  constructor(private _http: Http, private _roidealerservice: RoiDealerService, private _service: AppService) {
    this.model = { businesstype: '', state: '', email: '', prefcontact: true, desc: '', attachment: '', identype: '', id: '' };
    this.modelLabels = {
      'formHead': 'How can we help you today?',
      'formDescription':"Tell us exactly what you need and you'll hear from us within 72 hours.",
      'name': 'Full name',
      'nameDesc': 'Enter your name',
      'nameValidationError': 'Please enter a value',
      'mob': 'Mobile Number',
      'mobDesc': 'eg.+60 12345678',
      'mobEmptyError': 'Please enter a value',
      'mobLengthError': 'Please enter a value in range 7-12 digits',
      'mobValidationError': 'Please enter valid number',
      'altMob': 'Alternative Number',
      'companyName': 'Company Details',
      'companyDesc': 'Company Name',
      'ssmroc': 'SSM/ROC',
      'ssmrocValidationError': 'Please enter valid SSM/ROC with (-) dash, (/) slash and (@) alias ',
      'ssmrocEmptyError': 'Please enter a value',
      'ssmrocLengthError': 'Maximum allowed length is 20 characters only. Please enter a value in range',
      'stateDesc': 'State',
      'email': "Email Address",
      'emailDesc': "Enter your email",
      'emailValidationError': 'Please enter valid email ID',
      'address': 'Address',
      'addressDesc': 'Outlet Address',
      'address2Desc': 'Address2',
      'postcode': 'Postcode',
      'submit': 'Submit',
      'validError': "Validation error",
      'chooseState':'Please Select a State',
      'others': "Others"
      
      

    };
  };
  submitted = false;
  states = ['Cyberjaya/Putrajaya', 'Johor', 'Kedah', 'Kelantan', 'Melaka', 'Negeri Sembilan', 'Pahang', 'Perak', 'Perlis', 'Pulau Pinang', 'Sabah', 'Sarawak', 'Terengganu', 'W.P. Kuala Lumpur', 'W.P. Labuan', 'Selangor'];
  
  notificationPopup(msg,isSuccess) {
    if (typeof document !== undefined) {
      var modal = document.getElementById('sucessModal');
      var id = document.getElementById('sucessId');
      var heading = document.getElementById('msgHeadingId');
      id.innerHTML = msg;
      if(isSuccess){
        heading.innerHTML = "Successful Completion"
      }
      modal.style.display = "block";
    }
  }
 getErrorMessage(){
   return "Uh-oh! Something's off. Please try again.";
 }
 getSuccessMessage(){
   return "Got it! We've taken note of your interest. Someone will contact you within 3 working days";
 }
  onSubmit(dealerForm: NgForm) {
    this.msg = this.getErrorMessage();
    this._roidealerservice.findRoiAuthToken().subscribe(
      (value) => {
        this.token = value;
        this._roidealerservice.PostROIDealerFormData(this.token, dealerForm).subscribe(
          (response:any) => {
            this.handlePostDealerResponse(response);
          },
          err => {
            this.notificationPopup(this.msg,false);
          }
        );
      },
      (err: any) => {
        this.notificationPopup(this.msg,false);
      }

    );
  }

 handlePostDealerResponse(response){
  if(response.data.Items && response.data.Items.emailStatus == "PASS"){
    this.msg = this.getSuccessMessage();
    this.notificationPopup(this.msg,true);
  }
  else{
    this.notificationPopup(this.msg,false);
  }
 }  


}


