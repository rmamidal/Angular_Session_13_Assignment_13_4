import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseComponent} from '../../../base.component';
import {ContentNavigation} from '../../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../../Service/redirection.service';

@Component({
 selector: 'imagecard-without-overlay-component',
 templateUrl: './card-gallery-without-overlay.component.html',
 styleUrls: ['./card-gallery-without-overlay.component.css'], 
 providers:[RedirectionService] 
})
export class ImageCardWithoutOverlayComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public ImageCardData = null;   
  public ImageCardClass:string="";  
  constructor( private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService,
    private _router: Router
  ) {
      super();          
  }
    ngOnInit() {
    this.Init();
    }


  private Init() {
    if(this.data != undefined && this.data != null){
        this.ImageCardData = this.data;
        //commenting for this realese as this might be required in
        //next realese
         if(this.ImageCardData.length == 2 || this.ImageCardData.length == 1){
           this.ImageCardClass = "is-col-tablet-p-6 is-col-tablet-l-3 is-flex";
         }
         else{
           this.ImageCardClass = "is-col-tablet-p-4 is-equal-height";
         }
        //this.ImageCardClass = "is-col-tablet-p-4 is-equal-height";
    }
  }

  public ManageContentNavigation(data:any){      
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);
  }
  
}
    
 