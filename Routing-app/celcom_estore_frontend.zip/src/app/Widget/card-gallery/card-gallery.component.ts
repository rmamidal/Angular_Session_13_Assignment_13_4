 import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
 import {Observable} from 'rxjs/Rx';
 import "rxjs/add/operator/map";
 import {CardGalleryService} from "./card-gallery.service";
 import {AppWidgetComponent} from '../../Model/app.widget.component';
 import {BaseComponent} from '../../base.component';
 import {ContentNavigation} from '../../Model/contentnavigation.model'
 import {ActivatedRoute,Router} from '@angular/router';
 import {RedirectionService} from '../../Service/redirection.service';


@Component({
  selector: 'app-card-gallery',
  templateUrl: './card-gallery.component.html',
  styleUrls: ['./card-gallery.component.css'],
  providers:[CardGalleryService,RedirectionService]
})
export class CardGalleryComponent extends BaseComponent implements OnInit {
   @Input() data: any;
   public CardGalleryResponse = null;
   public AccordionData = null;
   public TabNavigationData: any;
   public SelectedTab: string = ''; 
   public AccordionDataByTab: any; 
   public IsDisplayTab:boolean = false;
   public BackgroundColor:string = "";
   public BackgroundImage:string = "";
   public IsInitializeImageCard:boolean=false;
   public IsInitializeImageCardOverlay:boolean=false;
   public ImageCardType:string = "";
   private _router:Router;
   constructor(private CardGalleryService:CardGalleryService,
     private _activatedRoute:ActivatedRoute,
     private _redirectionService:RedirectionService
     ) {
       super();
       this.TabNavigationData= [];
     //this.collageCard = [];
   }
  ngOnInit() {
    this.Init();
  }


   private Init() {     
     if(this.data && this.data.Api != undefined){
      this.IsDisplayTab = this.data.Tabs;
      this.BackgroundColor =  this.data.BackgroundColor;
      this.ImageCardType = this.data.Name;
      
      if(this.data.Desktop == '' || this.data.Mobile == ''){
        this.BackgroundImage = "";    
      }
      else{
        //TBD::for Mobile
        this.BackgroundImage = this.ApiUrl + this.data.Desktop.img;
      }

      if(this.BackgroundImage != '') {
        this.BackgroundColor = "";
      }
      else{
      
        this.BackgroundColor = this.BackgroundColor;

      }

      this.CardGalleryService.Find(this.data.Api).subscribe((response:any)=>{    
        this.CardGalleryResponse = response;
         if(this.CardGalleryResponse.Items.length > 0){   
           this.AccordionData = this.CardGalleryResponse.Items;
           this.ManageImagePath();            
           if(this.IsDisplayTab){            
            this.TabNavigationData = this.FindTabNavigationData(this.AccordionData);
            this.SelectedTab = this.TabNavigationData[0].Term;
            this.AccordionDataByTab = this.FindAccordionDataByActiveTab(this.AccordionData,this.SelectedTab); 
              if(this.ImageCardType=="imageCard") {
                this.IsInitializeImageCard = true;                
              }
              if(this.ImageCardType=="imageCardOverlay") {
                this.IsInitializeImageCardOverlay = true;                      
              }
           }
           else{             
            this.AccordionDataByTab = this.AccordionData;
            if(this.ImageCardType=="imageCard") {
              //this.IsInitializeImageCard = true;             
              this.ReInitializeImageCardComponent();
            }
            if(this.ImageCardType=="imageCardOverlay") {              
              this.ReInitializeImageCardOverlayComponent();                    
            }            
           }
         }
      });
     }     
}
      
    public OnTabSelect(item,index){      
      this.SelectedTab = item.Term;      
      this.AccordionDataByTab = this.FindAccordionDataByActiveTab(this.AccordionData,this.SelectedTab);
      this.ReInitializeSubComponent(this.ImageCardType);
    }

    private ReInitializeSubComponent(subComponentName:string){
      switch (subComponentName) {
        case "imageCard":
          this.ReInitializeImageCardComponent();
        break;
        case "imageCardOverlay":
          this.ReInitializeImageCardOverlayComponent();
        break;
      }      
    }
    private ReInitializeImageCardComponent(){      
      setTimeout(()=>{              
        this.IsInitializeImageCard = false;
      },0)
      setTimeout(()=>{
        this.IsInitializeImageCard = true;
      },0)
    } 
    private ReInitializeImageCardOverlayComponent(){      
      setTimeout(()=>{              
        this.IsInitializeImageCardOverlay = false;
      },0)
      setTimeout(()=>{
        this.IsInitializeImageCardOverlay = true;
      },0)
    } 
    private ManageImagePath(){
      this.AccordionData.forEach((item:any) => {
        item.BannerImage = this.ApiUrl + item.BannerImage;
      });
    }
    private FindAccordionDataByActiveTab(accordionData:Array<any>,activeTab:string){
      return accordionData.filter((item:any)=>{
        return (item.Category==activeTab);
      });
    }    

    private FindTabNavigationData(accordionData:Array<any>){
      let result = [];
      let counter = 0;
      accordionData.filter((item:any,index)=>{
        if(!this.IsAlreadyExist(result,item.Category)){
          result.push({
            Term:item.Category,
            Title:item.Category,
            HrefId:"#"+counter
          });
          counter = counter + 1;
        }      
      });
      return result;
    }
    private IsAlreadyExist(result:Array<any>,term:string):boolean{
      let data = result.filter((item:any)=>{
        return (item.Term==term);
      });
  
      if(data.length>0){
        return true;
      }
      else{
        return false;
      }
    }
  }
     
  