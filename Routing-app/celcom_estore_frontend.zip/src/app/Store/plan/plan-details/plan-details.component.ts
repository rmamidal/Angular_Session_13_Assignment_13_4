import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-plan-details',
  templateUrl: './plan-details.component.html',
  styleUrls: ['./plan-details.component.css']
})
export class PlanDetailsComponent implements OnInit {
  plan:any;
  public data = {
    Name:"ProductBannerMega",
    Api:"api/ProductBannerMega/239",
    PlanTable:
      { 
        Api:""
      }
  }
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {

    this.route.params.subscribe(params => {
      let id = params['planId'];
      this.data.PlanTable.Api = "/rest/V1/products/"+id;
    });

    //this.data.PlanTable.Api = '';
  }

}
