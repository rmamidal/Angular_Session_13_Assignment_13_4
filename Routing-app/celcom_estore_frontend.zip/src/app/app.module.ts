﻿import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { UniversalInterceptor } from './universal.interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import {router} from './app.router';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
//import {NgxCarouselModule} from 'ngx-carousel';
import {AppService} from './Service/app.service'
import {RoutesService} from "./Service/routes.service";
import {NotificationPopupEvent} from "./Service/broadcaster.service";
import {Broadcaster} from "./Model/broadcaster.model";
import {LocationStrategy, HashLocationStrategy} from "@angular/common";
import {NguCarouselModule} from '@ngu/carousel';

//import all component...
import { YoutubePlayerModule } from "ngx-youtube-player";
import { AppComponent } from './app.component';
import { HomeComponent } from './Home/home.component';
import { HeaderComponent } from './Header/header.component';
import { SubNavigationComponent } from './Header/SubNavigation/subnavigation.component';
import { FooterComponent } from './Footer/footer.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { SocialMediaComponent } from './Footer/SocialMedia/socialmedia.component'; 
import { NotificationComponent } from './Widget/notification/notification.component';
//import all widget...

import { ImportantNoticeComponent } from './Widget/important-notice/important-notice.component';
import {ProductCardComponent} from './Widget/ProductCard/productcard.component';
import {HeroBannerLeftLayoutComponent} from "./Widget/HeroBannerLeftLayout/herobannerleftlayout.component";
import {HeroBannerRightImageComponent} from './Widget/HeroBannerRightImage/herobanner.rightimage.component';
import {IconLayoutComponent} from './Widget/IconLayout/iconlayout.component';
import {StarRatingComponent} from './Widget/StarRating/starrating.component';
import {HeroBannerCarouselComponent} from './Widget/HeroBannerCarousel/herobanner.carousel.component';
import { HeroBannerImageClickableComponent } from './Widget/HeroBannerImageClickable/hero-banner-image-clickable.component';
import { TableComparisonComponent } from './Widget/table-comparison/table-comparison.component';
import { DetailBannerTextLeftComponent } from './Widget/DetailBannerTextLeft/DetailBannerTextLeft.component';
import { DetailBannerTextRightComponent } from './Widget/DetailBannerTextRight/DetailBannerTextRight.component';
import { BannerWithTableLeftComponent } from './Widget/banner-with-table-left/banner-with-table-left.component';
import { BannerWithTableRightComponent } from './Widget/banner-with-table-right/banner-with-table-right.component';
import { ProductBannerMegaComponent } from './Widget/product-banner-mega/product-banner-mega.component';
import { TableWithoutHeadingComponent } from './Widget/table-without-heading/table-without-heading.component';
import { CardGalleryCarouselComponent } from './Widget/card-gallery-carousel/card-gallery-carousel.component';
import { CallOutIconComponent } from './Widget/call-out-icon/call-out-icon.component';
import { CollageComponent } from './Widget/collage/collage.component';
import { DetailBannerLinkoutComponent } from './Widget/detail-banner-linkout/detail-banner-linkout.component';
import { VideoBannerComponent } from './Widget/video-banner/video-banner.component';
import { TestimonialsComponent } from './Widget/testimonials/testimonials.component';
import { ImgaeCardOverlayComponent } from './Widget/imgae-card-overlay/imgae-card-overlay.component';
import { ProductBannerTextLeftComponent } from './Widget/product-banner-text-left/product-banner-text-left.component';
import { deviceCarouselComponent } from './Widget/deviceCarousel/deviceCarousel.component';
import { ImageCard3Component } from './Widget/image-card3/image-card3.component';
//import { ProductBannerTextCenterComponent } from './Widget/product-banner-text-center/product-banner-text-center.component';
import { TabNavigationComponent } from './Widget/tab-navigation/tab-navigation.component';
import { TabRedirectionComponent } from './Widget/tab-redirection/tab-redirection.component';
import { AccordianComponent } from './Widget/accordian/accordian.component';
import { SearchHeaderComponent } from './Widget/search-header/search-header.component';
import { SearchBarComponent } from './Widget/search-bar/search-bar.component';
import { SearchFindingsComponent } from './Widget/search-findings/search-findings.component';
import { TitleBoxLinkComponent } from './Widget/title-box-link/title-box-link.component';
import {AppWidgetDirective}  from './app.widget.directive';
import {faqBannerComponent} from './Widget/faqBanner/faqBanner.component';
import {FeedbackComponent} from './Widget/feedback/feedback.component';
import {QuickLinksComponent} from './shared/components/quick-links/quick-links.component';
//ibm-moudules
import { AccordionModule } from './Widget/accordion-ibm/accordion.module'
import { OutageComponent } from './Widget/outage/outage.component';
import { MultistepsComponent } from './Widget/multisteps/multisteps.component';
import { CardGalleryComponent } from './Widget/card-gallery/card-gallery.component';
import { ImageCardOverlayComponent } from './Widget/card-gallery/card-gallery-overlay/card-gallery-overlay.component';
import { ImageCardWithoutOverlayComponent  } from './Widget/card-gallery/card-gallery-without-overlay/card-gallery-without-overlay.component';
//import { HeroBannerRightLayoutComponent } from './Widget/HeroBannerRightLayout/HeroBannerRightLayout.component';
import { HttpModule } from '@angular/http';
import { FreeContentComponent } from './Widget/freeContent/freeContent.component';
import { DetailBannerTextCenterComponent } from './Widget/detail-banner-text-center/detail-banner-text-center.component';
import { searchresultComponent } from './Widget/searchresult/searchresult.component';
import { JellyButtonComponent } from './Widget/xpax/jelly-button/jelly-button.component';
import { TabComponent } from './Widget/xpax/tab/tab.component';
import { TabsNewComponent } from './Widget/xpax/tabs-new/tabs-new.component';
import { InfoCardComponent } from './Widget/xpax/info-card/info-card.component';
import { PartnerCardComponent } from './Widget/xpax/partner-card/partner-card.component';
import { InfoCardTabsComponent } from './Widget/xpax/info-card-tabs/info-card-tabs.component';

//roi & other forms
import { BusinessRoiFormComponent } from './Widget/business-roi-form/business-roi-form.component' ;
import { RoiRetailComponent } from './Widget/roi-retail/roi-retail.component'
import { VideoCapaignComponent} from './Widget/video-capaign/video-capaign.component';
import { BgSliderComponent } from './Widget/BgSlider/bg-slider.component';
import {RoiDealerComponent} from './Widget/roi-dealer/roi-dealer.component';
import {CookieService} from 'ngx-cookie-service';

// Store Components.
import { DeviceHomeComponent } from './Store/device/device-home/device-home.component';
import { DeviceCatalogueComponent } from './Store/device/device-catalogue/device-catalogue.component';
import { DeviceDetailsComponent } from './Store/device/device-details/device-details.component';
import { PlanHomeComponent } from './Store/plan/plan-home/plan-home.component';
import { PlanDetailsComponent } from './Store/plan/plan-details/plan-details.component';
import { PlanComparisonComponent } from './Store/plan/plan-comparison/plan-comparison.component';
import { CartHomeComponent } from './Store/cart/cart-home/cart-home.component';

// Store widgets.
import { TopThreeComponent } from './Widget/StoreWidgets/top-three/top-three.component';
import { CatalogueBannerComponent } from './Widget/StoreWidgets/catalogue-banner/catalogue-banner.component';
import { ProgramComponent } from './Widget/StoreWidgets/program/program.component';
import { CatalogueBannerMegaComponent } from './Widget/StoreWidgets/catalogue-banner-mega/catalogue-banner-mega.component';
import { CatalogueComponent } from './Widget/StoreWidgets/catalogue/catalogue.component';
import { PlanBannerMegaComponent } from './Widget/StoreWidgets/plan-banner-mega/plan-banner-mega.component';
import { PlanTableComparisonComponent } from './Widget/StoreWidgets/plan-table-comparison/plan-table-comparison.component';
import { PlanDeviceComparisonComponent} from './Widget/StoreWidgets/plan-device-comparison/plan-device-comparison.component';
import { AddToCompareComponent} from './Widget/StoreWidgets/add-to-compare/add-to-compare.component'
import { HeroBannerClickableComponent } from './Widget/StoreWidgets/HeroBannerClickable/hero-banner-clickable.component'; 
import { DiviceFilterComponent } from "./Widget/StoreWidgets/divice-filter/divice-filter.component";


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    SubNavigationComponent,
    BgSliderComponent, 
    ImportantNoticeComponent,
    FooterComponent,
    SocialMediaComponent,
    ProductCardComponent,    
    HeroBannerRightImageComponent,
    IconLayoutComponent,
    StarRatingComponent,
    HeroBannerCarouselComponent,
    CardGalleryComponent,
    HeroBannerImageClickableComponent,
    TableComparisonComponent,
    DetailBannerTextRightComponent,
    BannerWithTableLeftComponent,
    BannerWithTableRightComponent,
    BreadcrumbComponent,
    ProductBannerMegaComponent,
    TableWithoutHeadingComponent,
    CardGalleryCarouselComponent,
    CallOutIconComponent,
    CollageComponent,
    DetailBannerLinkoutComponent,
    VideoBannerComponent,
    TestimonialsComponent,    
    DetailBannerTextLeftComponent,
    ImgaeCardOverlayComponent,
    ProductBannerTextLeftComponent,
    deviceCarouselComponent,
    ImageCard3Component,
    TabNavigationComponent,
    TabRedirectionComponent,
    AccordianComponent,
    SearchHeaderComponent,
    SearchBarComponent,
    SearchFindingsComponent,
    TitleBoxLinkComponent,    
    AppWidgetDirective,
    faqBannerComponent,
    NotificationComponent ,
    OutageComponent,
    FeedbackComponent,
    QuickLinksComponent,
    //HeroBannerRightLayoutComponent,
    HeroBannerLeftLayoutComponent,
    MultistepsComponent,
    ImageCardOverlayComponent,
    ImageCardWithoutOverlayComponent,    
    FreeContentComponent, DetailBannerTextCenterComponent,
    searchresultComponent,
    BusinessRoiFormComponent, 
    RoiRetailComponent,
    JellyButtonComponent,
    TabComponent,
    TabsNewComponent,
    InfoCardComponent,
    PartnerCardComponent,
    InfoCardTabsComponent,
    VideoCapaignComponent,
    BgSliderComponent,
    RoiDealerComponent,
    //Store components.
    DeviceHomeComponent,
    TopThreeComponent,
    CatalogueBannerComponent,
    ProgramComponent,
    DeviceCatalogueComponent,
    CatalogueBannerMegaComponent,
    CatalogueComponent,
    DeviceDetailsComponent,
    PlanHomeComponent,
    PlanDetailsComponent,
    PlanBannerMegaComponent,
    PlanComparisonComponent,
    PlanTableComparisonComponent,
    PlanDeviceComparisonComponent,
    AddToCompareComponent,
    CartHomeComponent,
    HeroBannerClickableComponent,
    DiviceFilterComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'universal' }),
    HttpClientModule,
    HttpModule,
    FormsModule,    
    NguCarouselModule,
    AccordionModule,
    YoutubePlayerModule,
    RouterModule.forRoot(router)    
  ],
  entryComponents:[
    FooterComponent,
    BgSliderComponent, 
    ImportantNoticeComponent,
    StarRatingComponent,
    IconLayoutComponent, 
    HeroBannerCarouselComponent,
    ProductCardComponent,
    HeroBannerImageClickableComponent,
    HeroBannerRightImageComponent,
    faqBannerComponent,
    AccordianComponent,
    DetailBannerTextLeftComponent,
    DetailBannerTextRightComponent,
    ProductBannerMegaComponent,
    CollageComponent,
    CallOutIconComponent,
    DetailBannerLinkoutComponent,
    BannerWithTableLeftComponent,
    BannerWithTableRightComponent,
    TableComparisonComponent,
    TabNavigationComponent,
    TabRedirectionComponent,
    //HeroBannerRightLayoutComponent,
    HeroBannerLeftLayoutComponent,
    MultistepsComponent,
    CardGalleryComponent,
    VideoBannerComponent,    
    ProductBannerTextLeftComponent,
    deviceCarouselComponent,
    TestimonialsComponent,
    FreeContentComponent,
    DetailBannerTextCenterComponent,
    QuickLinksComponent,
    searchresultComponent,
    InfoCardComponent,
    PartnerCardComponent,
    InfoCardTabsComponent,
    VideoCapaignComponent,
    OutageComponent,
    RoiDealerComponent,
    RoiRetailComponent,
    BusinessRoiFormComponent
  ],
  providers: [AppService,RoutesService,Broadcaster,NotificationPopupEvent,CookieService],
  bootstrap: [AppComponent]
})
export class AppModule {  
  private MY_ROUTE:string = "MY_ROUTE";
  private MyAppRoutes:Array<any>;
  
  constructor(private routesservice: RoutesService,private _router:Router){   
    this.MyAppRoutes = [];
    //this.RemoveLocalStorage();
    //this.FindAppRoutes();
  }  
  private FindAppRoutes() {
    this.routesservice.Find().subscribe((data:any)=>{  
      this.ManagedynamicRoute(data);
    });
  }

  private ManagedynamicRoute(routeData){
    routeData.forEach((item:any) => {
      item.alias = item.alias.substr(1);
      this.MyAppRoutes.push({ 
        path: item.alias, 
        component : HomeComponent,
        data:{"EndPoint":item.end_point}
      });
      this.AddRouteToLocalStorage(routeData);    
    });
    this._router.resetConfig(this.MyAppRoutes);        
    
  }
  private RemoveLocalStorage(){
    //if exist..
    if (typeof window !== 'undefined') {
      localStorage.removeItem(this.MY_ROUTE);
    }
  }
  private AddRouteToLocalStorage(data){
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.MY_ROUTE,JSON.stringify(data));
    }
    
  }
  
}



//Angular Universal...
//https://www.youtube.com/watch?v=lncsmB5yfzE
//cousetro.com
//For Dyanmic Routing...
//https://github.com/angular/angular-cli/issues/4234