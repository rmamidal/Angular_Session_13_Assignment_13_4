import {Headers,RequestOptions} from '@angular/http';
import * as environment from '../../environment.json'

export class BaseService {
    BaseUrl:string;
    AppAuth:string;
    constructor(){        
        this.BaseUrl = (<any>environment).nodeUrl;
    }  

    public GenerateHeader():RequestOptions{
        let _headers = new Headers();
        _headers.append("Content-Type","application/hal+json");
        let options = new RequestOptions({ headers: _headers });
        return options;
    }
    public GenerateEstoreHeader():RequestOptions{
        let _headers = new Headers();
        _headers.append("Content-Type","application/hal+json");
        let options = new RequestOptions({ headers: _headers });
        return options;
    }
}