import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseService } from '../base.service';
import  {AppService} from './app.service';
import { Product } from '../Model/product.model';
import { CompareProduct } from '../Model/product-compare.model';

const PRODUCT_COMPARE_KEY = "product_compare";

@Injectable()
export class CompareProductService extends BaseService {
	
	constructor(private _service:AppService) {
		super();
	}

  	public Find(apiURL:string):Observable<any[]> {  
      	let url = apiURL.replace(/[+_]/g,'%2B');
      	let options = this.GenerateHeader();    
      	return this._service
      	.getEstoreData(url)
      	.map((response:any) => {
          return response
      	})        
    }
    
	public addProductToCompare(product:any): void {
        const compProduct = this.retrieveProduct();
        let prod = compProduct.noOfProds.find((p) => p.sku == product);
        let prodCount = compProduct.noOfProds.length;
       
        if(prod == undefined && prodCount <=2) {
            prod = new Product();
            prod.sku = product;
            compProduct.noOfProds.push(prod);
            alert(prod.sku +" added to Compare products");
        }
        else if(prodCount == 3) {
            alert("No. of products added are more then 3.");
        }
        this.save(compProduct);
    }
    
    public retrieveProduct(): CompareProduct {
        const product = new CompareProduct();
        const storedProduct = localStorage.getItem(PRODUCT_COMPARE_KEY);
        if (storedProduct) {
            product.setCompareProd(JSON.parse(storedProduct));
        }
        return product;
    }

    private save(product:CompareProduct): void {
        localStorage.setItem(PRODUCT_COMPARE_KEY, JSON.stringify(product));
    }

    public removeProductFromCompare(product:any){
        const compProduct = this.retrieveProduct();
        let prod = compProduct.noOfProds.find((p) => p.sku === product);
        if (prod != undefined) {
            compProduct.noOfProds = compProduct.noOfProds.filter((item) => item != prod);
        }
        this.save(compProduct);
    }

    public removeAllProductFromCompare(){
        const compRmAllProduct = this.retrieveProduct();
        compRmAllProduct.noOfProds = [];
        this.save(compRmAllProduct);
    }
}
