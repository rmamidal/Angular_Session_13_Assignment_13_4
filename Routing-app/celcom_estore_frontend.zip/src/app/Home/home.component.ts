import { Component,OnInit,Input, AfterViewInit, ViewChild, ComponentFactoryResolver, OnDestroy,ViewContainerRef,ComponentRef } from '@angular/core';
import { HomeService } from '../Service/home.service';
import {BaseComponent} from '../base.component'
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {TemplateList} from '../app.template';
import {AppComponentList} from '../component.config'
import {PageComponentListModel} from '../Model/pagecompoentlist.model';
import {AddWidget} from '../Model/addwidget.model';
import {AppWidgetDirective} from '../app.widget.directive'
import {AppWidgetComponent} from '../Model/app.widget.component';

//import all widget...
import { ImportantNoticeComponent } from '../Widget/important-notice/important-notice.component';
import { BreadcrumbComponent } from '../breadcrumb/breadcrumb.component';
import { TestimonialsComponent } from '../Widget/testimonials/testimonials.component';
import { BannerWithTableLeftComponent } from '../Widget/banner-with-table-left/banner-with-table-left.component';
import { BannerWithTableRightComponent } from '../Widget/banner-with-table-right/banner-with-table-right.component';
import { CallOutIconComponent } from '../Widget/call-out-icon/call-out-icon.component';
import { CollageComponent } from '../Widget/collage/collage.component';
import { DetailBannerLinkoutComponent } from '../Widget/detail-banner-linkout/detail-banner-linkout.component';
import { DetailBannerTextLeftComponent } from '../Widget/DetailBannerTextLeft/DetailBannerTextLeft.component';
import { DetailBannerTextRightComponent } from '../Widget/DetailBannerTextRight/DetailBannerTextRight.component';
import { HeroBannerCarouselComponent } from '../Widget/HeroBannerCarousel/herobanner.carousel.component';
import { HeroBannerImageClickableComponent } from '../Widget/HeroBannerImageClickable/hero-banner-image-clickable.component';
import { HeroBannerRightImageComponent } from '../Widget/HeroBannerRightImage/herobanner.rightimage.component';
import { IconLayoutComponent } from '../Widget/IconLayout/iconlayout.component';
import { ProductBannerMegaComponent } from '../Widget/product-banner-mega/product-banner-mega.component';
import { ProductCardComponent} from '../Widget/ProductCard/productcard.component';
import { StarRatingComponent} from '../Widget/StarRating/starrating.component';
import { TabNavigationComponent } from '../Widget/tab-navigation/tab-navigation.component';
import { TabRedirectionComponent } from '../Widget/tab-redirection/tab-redirection.component';
import { TableComparisonComponent } from '../Widget/table-comparison/table-comparison.component';
import { TableWithoutHeadingComponent } from '../Widget/table-without-heading/table-without-heading.component';
import {faqBannerComponent} from '../Widget/faqBanner/faqBanner.component';
import {AccordianComponent} from '../Widget/accordian/accordian.component';
import {OutageComponent} from '../Widget/outage/outage.component';
import { FeedbackComponent } from '../Widget/feedback/feedback.component';
import { MultistepsComponent } from '../Widget/multisteps/multisteps.component';
import { CardGalleryComponent } from '../Widget/card-gallery/card-gallery.component';
import { deviceCarouselComponent } from '../Widget/deviceCarousel/deviceCarousel.component';
import { VideoBannerComponent } from '../Widget/video-banner/video-banner.component';
import { ProductBannerTextLeftComponent } from '../Widget/product-banner-text-left/product-banner-text-left.component';
import { FreeContentComponent } from '../Widget/freeContent/freeContent.component';
import { DetailBannerTextCenterComponent } from '../Widget/detail-banner-text-center/detail-banner-text-center.component';
import { QuickLinksComponent} from '../shared/components/quick-links/quick-links.component';
//import {HeroBannerRightLayoutComponent} from '../Widget/herobannerrightlayout'
import { InfoCardTabsComponent } from '../Widget/xpax/info-card-tabs/info-card-tabs.component';
import { PartnerCardComponent } from '../Widget/xpax/partner-card/partner-card.component';

//to handle route...
import {ActivatedRoute,Router} from '@angular/router';
import {RoutesService} from "../Service/routes.service";


// to handle meta tags
import { Meta } from '@angular/platform-browser';
// to handle the feedback
import {NotificationPopupEvent} from '../Service/broadcaster.service';
import {ContentNavigation} from '../Model/contentnavigation.model';
import {RedirectionService} from '../Service/redirection.service';
import {FooterComponent} from '../Footer/footer.component';
import * as urlUtility from '../Utility/url.utility';
import {VideoCapaignComponent } from '../Widget/video-capaign/video-capaign.component';

//elastic-serach
import { searchresultComponent } from '../Widget/searchresult/searchresult.component';

//
import { BusinessRoiFormComponent } from '../Widget/business-roi-form/business-roi-form.component' ;
import { RoiRetailComponent } from '../Widget/roi-retail/roi-retail.component';
import {RoiDealerComponent} from '../Widget/roi-dealer/roi-dealer.component';

/* Store Landing component */
import { DeviceHomeComponent } from '../Store/device/device-home/device-home.component';
import { PlanHomeComponent } from '../Store/plan/plan-home/plan-home.component';
import { CartHomeComponent } from '../Store/cart/cart-home/cart-home.component';
import { DeviceCatalogueComponent } from '../Store/device/device-catalogue/device-catalogue.component';

@Component({
  selector: 'home-component',
  templateUrl: './home.component.html',
  providers:[HomeService,RedirectionService]
})

export class HomeComponent extends BaseComponent  implements OnInit {
    public current_url:any; 
    private templateList = TemplateList;
    private widgetList = AppComponentList;
    private PageComponentList:Array<PageComponentListModel> = [];
    private widget: AddWidget[];
    currentAddIndex: number = -1;
    @ViewChild(AppWidgetDirective) appDirective: AppWidgetDirective;
    private AppComponentList =[
      {
        Name:"HeroBanner Carousel",
        Key:"heroBanner_carousel",
        component:HeroBannerCarouselComponent      
      },
      {
          Name:"Accordian",
          Key:"accordian",
          component:AccordianComponent      
      },
      {
        Name: "ImportantAnnouncement",
        Key: "importantAnnouncement",
        component: ImportantNoticeComponent
      },
      {
        Name:"BannerWithTableLeft",
        Key:"bannerwithtableleft",
        component:BannerWithTableLeftComponent
      },
      {
        Name:"BannerWithTableRight",
        Key:"bannerwithtableright",
        component:BannerWithTableRightComponent
      },
      {
        Name:"CalloutIcon",
        Key:"callouticon",
        component:CallOutIconComponent
      },
      {
        Name:"Collage",
        Key:"collage",
        component:CollageComponent
      },
      {
        Name:"DatailBannerLinkout",
        Key:"detailBanner_linkout",
        component:DetailBannerLinkoutComponent
      },
      {
        Name:"DatailBannerTextLeft",
        Key:"detailBanner_left",
        component:DetailBannerTextLeftComponent
      },
      {
        Name:"DetailBannerTextRight",
        Key:"detailBanner_right",
        component:DetailBannerTextRightComponent
      },
      {
        Name:"HeroBannerCarousel",
        Key:"herobannercarousel",
        component:HeroBannerCarouselComponent
      },
      {
        Name:"HeroBannerImageClickable",
        Key:"heroBanner_img_clickable",
        component:HeroBannerImageClickableComponent
      },
      
      {
        Name:"HeroBannerRightLayout",
        Key:"herobanner_right_layout",
        component:HeroBannerRightImageComponent
      },
      {
        Name:"IconLayout",
        Key:"iconlayout",
        component:IconLayoutComponent
      },
      {
        Name:"ProductBannerMega",
        Key:"productbannermega",
        component:ProductBannerMegaComponent
      },
      {
        Name:"ProductCard",
        Key:"productcard_left",
        component:ProductCardComponent
      },
      {
        Name:"ProductCard",
        Key:"productCard_center",
        component:ProductCardComponent
      },
 
      {
        Name:"StarRating",
        Key:"starRatingApi",
        component:StarRatingComponent
      },
      {
        Name:"TabRedirection",
        Key:"tabNavigationRedirection",
        component:TabRedirectionComponent
      },
      {
        Name:"TabNavigation",
        Key:"tabNavigation",
        component:TabNavigationComponent
      },
      {
        Name:"TableComparison",
        Key:"tablecomparison",
        component:TableComparisonComponent
      },
      {
        Name:"TableComparisonXPAX",
        Key:"prepaidPlan",
        component:TableComparisonComponent
      },
      {
        Name:"TableWithoutHeading",
        Key:"tablewithoutheading",
        component:TableWithoutHeadingComponent
      },
      {
        Name:"faqBanner",
        Key:"FaqBanner",
        component:faqBannerComponent
      },
      {
        Name:"Accordion",
        Key:"FAQ",
        component:AccordianComponent
      },
      {
        Name:"BannerWithTableRight",
        Key:"tableBannerRight",
        component:BannerWithTableRightComponent
      },
      {
        Name:"BannerWithTableLeft",
        Key:"tableBannerLeft",
        component:BannerWithTableLeftComponent
      },
      {
        Name:"MultistepsComponent",
        Key:"multiSteps",
        component:MultistepsComponent
      },
      {
        Name:"CardGalleryComponent",
        Key:"imageCardOverlay",
        component:CardGalleryComponent
      },
      {
        Name:"CardGalleryComponent",
        Key:"imageCard",
        component:CardGalleryComponent
      },
      {
        Name:"VideoBannerComponent",
        Key:"videoBanner", 
        component:VideoBannerComponent
      },      
      {
        Name: "ProductBannerTextLeft",
        Key: "productBanner", 
        component: ProductBannerTextLeftComponent
      },
      {
        Name: "deviceCarouselComponent",
        Key: "deviceCarousal", 
        component: deviceCarouselComponent
      },
      {
        Name: "testimonialsComp",
        Key: "testimonials", 
        component: TestimonialsComponent
        },
        {
          Name: 'freecontentComp',
          Key: 'freeContent',
          component: FreeContentComponent
        },
        {
          Name: 'footer',
          Key: 'footer',
          component: FooterComponent
        },
        {
        Name:"QuickLinks",
        Key:"quicklinks",
        component:QuickLinksComponent
      }, 
        {
          Name: 'detailBanner_centre',
          Key: 'detailBanner_centre',
          component: DetailBannerTextCenterComponent
        },          
        {
        Name:"ElasticSearch",
        Key:"globalSearch",
        component:searchresultComponent
      },
        {
          Name: 'InfoCard',
          Key: 'infocard',
          component: InfoCardTabsComponent
        },
        {
          Name: 'PartnerCard',
          Key: 'partnersCard',
          component: PartnerCardComponent
        },
        {
          Name: 'videoCampaign',
          Key: 'videoCampaign',
          component: VideoCapaignComponent
        },
        {
          Name: 'OutageComponent',
          Key: 'outage',
          component: OutageComponent
        },
        {
          Name: 'RoiRetail',
          Key: 'roiRetail',
          component: RoiRetailComponent
        },
        {
          Name: 'RoiBusiness',
          Key: 'roiBusiness',
          component: BusinessRoiFormComponent
        },
        {
          Name: 'RoiDealer',
          Key: 'roiDealer',
          component: RoiDealerComponent
        },
    ]
    
    constructor(private _service:HomeService,
      private componentFactoryResolver: ComponentFactoryResolver,
      private viewContainer: ViewContainerRef,
      private _activatedRoute:ActivatedRoute,
      private _router:Router,
      private _routerService: RoutesService,
      private metaService: Meta,
      private notificationEvent: NotificationPopupEvent,
      private _redirectionService:RedirectionService
      ){
        super();
      this.PageComponentList = [];
      //manage dynamic route
      this.MyAppRoutes = [];
      this.RemoveLocalStorage();
      this.FindAppRoutes();
    }

    ngOnInit(){         
      this.RegisterTypeBroadcast();
    }

    private Init(){
      //get widget list from api..      
    }
    private Bind(currentRouteInfo:any):void{
      let footerData = {
        "Api": "",
        "Name":"footer"
      }
      this._service.FindTemplateComponents(currentRouteInfo.EndPoint).subscribe((response:any)=>{ 
        let result = response;
        result.data.component.push(footerData);
        this.FindPageComponentList(result.data.component);  
        this.ManageMetaTags(result.data.metaTags);  
        this.SetTemplateType(result);
      });
    }

    //handle template type 
    public IsXpaxTheme:boolean=false;
    private SetTemplateType(result:any){
      let template = result['SelectTemplate'];      
      if (typeof window !== 'undefined') {
        if(template==='xpax'){
          localStorage.setItem("TemplateType",template);
          this.IsXpaxTheme = true;          
        }
        else{
          localStorage.setItem("TemplateType","default");
          this.IsXpaxTheme = false;
        }
      }
    }
    //filter from appComponentList
    private FindPageComponentList(componentData){
      componentData.forEach((item:any) => {
        if(item != null){        
          if(item.Name!='breadcrumb'){
            let result = this.FilterFromWidgetList(item); 
            if(result!=undefined && result.length > 0){             
              this.PageComponentList.push(new PageComponentListModel(result[0].Name,result[0].component,item,false)); 
            } 
          }
          else{
            this.ManageBreadcrumb(item);
          }
        }       
      }); 
      this.widget = this.GetMyWidgets(this.PageComponentList);
      this.widget.forEach((widgetItem:AddWidget) => {         
        this.LoadComponent(widgetItem);     
      });
    }

    //breadcrumb..
    public BreadcrumbApiUrl:string = "";
    private ManageBreadcrumb(breadcrumb:any){
      this.BreadcrumbApiUrl = breadcrumb.Api;
    }
    private ManageMetaTags(metaTags:any){      
      if(metaTags != null && metaTags.length>0){
        if(metaTags[0].SeoTags != null && metaTags[0].SeoTags.length>0){          

          metaTags[0].SeoTags.forEach((seo:any) => {            
              this.metaService.addTags([
                { name: seo.TagKey, content: seo.TagContent }
              ]);  
          });       
          
        }
      }
    }
    private FilterFromWidgetList(item:any){
       return this.AppComponentList.filter((widgetItem)=>{
         return (widgetItem.Key.toUpperCase() == item.Name.toUpperCase())
       }); 
    }

    private LoadComponent(widgetItem:AddWidget) {
      // this.currentAddIndex = (this.currentAddIndex + 1) % this.PageComponentList.length;
      // let widgetItem = this.widget[this.currentAddIndex];   
      setTimeout(()=>{
        let widgetClass = widgetItem.component;   
        let componentFactory = this.componentFactoryResolver.resolveComponentFactory(widgetItem.component);
        let viewContainerRef = this.appDirective.viewContainerRef;
        //viewContainerRef.clear();
        let componentRef = viewContainerRef.createComponent(componentFactory);
        (<AppWidgetComponent>componentRef.instance).data = widgetItem.data;
        componentRef.changeDetectorRef.detectChanges();
      }, 0);
    }
 
      private GetMyWidgets(pagecompoentlist:any){
        let result = []
        pagecompoentlist.forEach((item:PageComponentListModel)=>{
          result.push(
            new AddWidget(item.Widget, item.Data)
          )
        })
        return result;
      }

      private MY_ROUTE:string = "MY_ROUTE";
      private MyAppRoutes:Array<any>;

      private FindAppRoutes() {
        this._routerService.Find().subscribe((data:any)=>{  
          this.ManagedynamicRoute(data.Items);
          if(data.GlobalSettings!=null && data.GlobalSettings.length>0){            
            //this.InjectHeaderFooterScript(data.GlobalSettings);
          }
        });
      }

      private InjectHeaderFooterScript(data:any){
        this._service.ManageConfigurableScripts(data);        
      }
      private ManagedynamicRoute(routeData){

        this.MyAppRoutes.push({ 
          path: 'personal/devices', 
          component : DeviceHomeComponent,
        });

        this.MyAppRoutes.push({ 
          path: 'store/devices', 
          component : DeviceCatalogueComponent,
        });

        this.MyAppRoutes.push({ 
          path: 'personal/postpaid', 
          component : PlanHomeComponent,
        });

        this.MyAppRoutes.push({ 
          path: 'store/cart', 
          component : CartHomeComponent,
        });

        routeData.forEach((item:any) => {
          item.alias = item.alias.substr(1);
           //adding routes explicitly to handle back button ->home
           if(item.type == "home"){
            this.MyAppRoutes.push({ 
              path: '', 
              component : HomeComponent,
              data:{"EndPoint":item.end_point}
            }); 
          }

          this.MyAppRoutes.push({ 
            path: item.alias, 
            component : HomeComponent,
            data:{"EndPoint":item.end_point}
          });          
        });
        //adding routes for elastic search
        this.MyAppRoutes.push({ 
          path: 'search', 
          component : searchresultComponent              
        }); 
        this.MyAppRoutes.push({ 
          path: 'search/:searchkey', 
          component : searchresultComponent              
        }); 

        this._router.resetConfig(this.MyAppRoutes);        
        this.AddRouteToLocalStorage(routeData);            
      }
      private RemoveLocalStorage(){
        //if exist..
        if (typeof window !== 'undefined') {
          localStorage.removeItem(this.MY_ROUTE);
          localStorage.removeItem("TemplateType");
        }
      }
      private AddRouteToLocalStorage(data){
        if (typeof window !== 'undefined') {
          localStorage.setItem(this.MY_ROUTE,JSON.stringify(data));     
        }                                  
        this._activatedRoute.data.subscribe((item:any)=>{  
          //get the current browser url to route accordingly 
          this.current_url = this._router.routerState.snapshot.url;       
          let currentUrl = urlUtility.getCurrentBrowserUrlWithoutQueryString(this._router.routerState.snapshot.url);
          let endPointInfo;
          //To map to the component corresponding to type as home            
          let isUrlContainsHash = this.IsUrlContainsHash(currentUrl);
          let isElasticSerachUrl =this.IsElasticSearchUrl(currentUrl);
          if(isUrlContainsHash){            
            let splitResult = this.SplitHashBasedUrl(currentUrl);
            endPointInfo = this.getAPIEndPoint(data,splitResult);  
          }   
          else if(isElasticSerachUrl){
            //navigate to elastic search component...
            this._router.navigate([currentUrl]);
          }       
          else{
            endPointInfo = this.getAPIEndPoint(data,currentUrl);           
          }         
          
          if(endPointInfo!=null){
            this.Bind({"EndPoint":endPointInfo.end_point});  
          } 
        }); 
      }
      /**
       * Get endpoint (api url) for respective browser url
       * if empty url "x.com/" then load homepage
       * for anyother url get endpoint 
       * if endpoint not found call pagenotfound api
       * @param data 
       * @param currentUrl 
       */
      private getAPIEndPoint(data:any,currentUrl:string){
        if(currentUrl == ""){                
          return this.getHomePageDetails(data);                           
        }
        else{
          let pagedata = this.FindApiEndPoint(data,currentUrl);
           if(pagedata){
              return pagedata;
           }
           else{
            return this.getPageNotFoundDetails(data);
           }       
        }
      }
      private FindApiEndPoint(data:any,alias:string){
          let result = data.filter((item:any) => {
            return (item.alias == alias)
          });          
          return result[0];
      }
      /**
       * Method to check which is home page and route accordingly
       * if no page is mapped for type home then
       * personal page will be loaded as homepage
       * @param data 
       */
      private getHomePageDetails(data:any){
        let result = data.filter((item:any) => {
          return (item.type == "home")
        });
        if(result.length>0){
          return result[0];
        }          
        else{
          return this.FindApiEndPoint(data,"personal");
        }
      }
      /**
       * get api for page not found
       * @param data 
       */
      private getPageNotFoundDetails(data:any){
        let result = data.filter((item:any) => {
          return (item.type == "page_404")
        });
        return result[0];
      }
      //
      
      //Content-heavy/Faq Page
      private IsUrlContainsHash(currentUrl){        
        let result:boolean = currentUrl.indexOf("#") > -1;
        return result;
      }
      private IsElasticSearchUrl(currentUrl){        
        let result:boolean = currentUrl.indexOf("search") > -1;
        return result;
      }
      private SplitHashBasedUrl(currentHashUrl){
        let splitResult="";
        if(currentHashUrl!=null)
        {
          let result = currentHashUrl.split('#');
          if(result.length>0){
            splitResult = result[0];
          }
        }
        return splitResult;

      }
      //

      //Manage Global Notification popup
      public IsInitialized:boolean =false;
      public RedirectionInfo:any;
      public RegisterTypeBroadcast() {
        this.notificationEvent.on().subscribe((data:any) => {                    
          this.ManageNotificationPopup(data);    
        });		
      }
      private ManageNotificationPopup(data:any):void{
        switch (data.Type) {
          case "CLOSE":
            setTimeout(()=>{              
              this.IsInitialized = true;
            },0)
            setTimeout(()=>{
              this.IsInitialized = false;
            },0)
          break;
          case "OPEN":
            setTimeout(()=>{
              this.IsInitialized = false;
            },0)
            setTimeout(()=>{
              this.RedirectionInfo = data.Data;
              this.IsInitialized = true;
            },0)
          break;          
        }
      }
      //
      
}

 