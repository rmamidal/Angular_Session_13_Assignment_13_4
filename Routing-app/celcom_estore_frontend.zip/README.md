# MyTest

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.5.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


## Dos and Don'ts before start coding

1. Dont use window directly. Either use isPlatformBrowser method from '@angular/common" or use if(typeof window !== undefined) before doing window.something.
2. Above rule is applicable for document and localstorage too.
3. Avoid using hammer.js - Try a work around for this.

## Development - Client Side rendering

To create a component use client side rendering. Please follow the steps below

1. Open a cmd prompt and go to celcom_portal_angular folder and run "node server".
2. Open another cmd prompt and go to celcom_portal_angular folder and run "npm start"
3. In "app.service.js" uncomment line no 16 and comment line no 17  

## Integration Testing - Server side rendering

Once a component is created, before committing the code changes run the application in server side. Please follow the below steps

In "app.service.js" uncomment line no 17 and comment line no 16   
To run directly-    "npm run start:dynamic"
To build and run-  
 1. "npm run build:dynamic"
 2. "npm run serve:dynamic"


## Referrence for angular universal 
https://angular.io/guide/universal

## Redis
Redis is not supported in windows. Please make isRedisCacheEnabled as always false in environment.json in local

To remove node js error for redis in local in webpack.server.config.js comment line no 15, and uncomment line no 17 and 18.

Revert the above changes while commiting the code.

## YARN
## YARN local first setup
npm install
npm i -g yarn && npm i --save yarn && yarn --version  

## YARN first time setup server  
npm i -g yarn    
yarn --version 
yarn install


## YARN  second time run in server  
yarn install 
npm prune
