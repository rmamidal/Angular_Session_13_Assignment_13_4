import 'zone.js/dist/zone-node';
import 'reflect-metadata';
import { renderModuleFactory } from '@angular/platform-server';
import { enableProdMode } from '@angular/core';

import * as express from 'express';
import { join } from 'path';
import { readFileSync } from 'fs';
import * as compression from 'compression';
import * as environment from './environment.json';
import * as apiController from './src/controller/apiController';
import * as redisController from './src/controller/redisController';
import * as elasticSearchController from './src/controller/elasticSearchController';


var cors = require('cors');
var bodyParser = require('body-parser');
var fs = require('fs');
var http = require('http');
var bodyParser = require('body-parser');



//var privateKey  = fs.readFileSync('./ssl/private.pem', 'utf8');
//var certificate = fs.readFileSync('./ssl/public.pem', 'utf8');

//var credentials = {key: privateKey, cert: certificate};

// Faster server renders w/ Prod mode (dev mode never needed)
enableProdMode();

// Express server
const app = express();

const PORT = 8080;
const DIST_FOLDER = join(process.cwd(), 'dist');

// Our index.html we'll use as our template
const template = readFileSync(join(DIST_FOLDER, 'browser', 'index.html'), { encoding: 'utf8' }).toString();

// * NOTE :: leave this as require() since this file is built Dynamically from webpack
const { AppServerModuleNgFactory } = require('./dist/server/main.bundle');

// Express Engine
import { ngExpressEngine } from '@nguniversal/express-engine';

/* Server-side rendering */
function angularRouter(req, res) {
  res.render(join(DIST_FOLDER, 'browser', 'index.html'), {
    req: req,
    res: res,
    providers: [{
      provide: 'serverUrl',
      useValue: `http://localhost:8080`
    }]
  });

}
app.get('/', angularRouter);

// Our Universal express-engine (found @ https://github.com/angular/universal/tree/master/modules/express-engine)
app.engine('html', ngExpressEngine({
  bootstrap: AppServerModuleNgFactory
}));


app.set('view engine', 'html');
app.set('views', join(DIST_FOLDER, 'browser'));

/* - Example Express Rest API endpoints -
  app.get('/api/**', (req, res) => { });
*/
// Body-Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(compression());
// Cors
app.use(cors());
// Add headers

app.get('/getDrupalSessionToken',(req,res) =>{
  apiController.getDrupalSession(req,res);
});

app.get('/api/*', (req,res)=>{
  if((<any>environment).isRedisCacheEnabled){
    redisController.readFromCache(req,res);
  }
  else{
    apiController.getApi(req,res);
  }
}); 

app.get('/_search',(req,res)=>{
    elasticSearchController.getSearchData(req,res);
});

app.post('/api/*', (req,res)=>{
  apiController.postData(req,res);
});

app.post('/email_rest_resource', (req,res) => {
  apiController.postDataToDrupal(req,res);
});

//Estore.
app.get('/rest/*', (req,res)=>{
  if((<any>environment).isRedisCacheEnabled){
    redisController.readFromCache(req,res);
  }
  else {
    apiController.getEstoreApi(req,res);
  }
});

app.post('/rest/*', (req,res)=>{
  apiController.postEstoreData(req,res);
});
// Server static files from /browser
app.get('*.*', express.static(join(DIST_FOLDER, 'browser'), {
  maxAge: '1y'
}));

// ALl regular routes use the Universal engine
app.get('*', angularRouter);

http.createServer(app).listen(PORT, function () {
  console.log('Server started!');
});