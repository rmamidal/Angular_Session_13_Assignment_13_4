eStore Angular Codebase
