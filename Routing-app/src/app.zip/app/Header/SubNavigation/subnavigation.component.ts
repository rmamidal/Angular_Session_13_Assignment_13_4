import { Component, Input, Output, OnInit,EventEmitter } from '@angular/core';
import { ContentNavigation } from '../../Model/contentnavigation.model'
import { ActivatedRoute, Router } from '@angular/router';
import { RedirectionService } from '../../Service/redirection.service'


@Component({
  selector: 'header-subnavigation-component',
  templateUrl: './subnavigation.component.html',
  providers: [RedirectionService],
  styles:[
    `li .navigation__list-item > a{
      padding-right: 20px
    }`
  ]
})

export class SubNavigationComponent implements OnInit {
  @Input() NavigationInfo: any;
  @Input() SelectedMenu:any;
  @Input() GlobalNavigationInfo:any;
  @Output() OnMobileMenuSelect:EventEmitter<any> = new EventEmitter();  
  RemainingParentMenu:any;
  menu:string;
  Data: any;
  constructor(
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private _redirectionService: RedirectionService) {
    this.Data = null;
  }
  ngOnInit() {
    if (this.NavigationInfo!) {
      this.menu=this.SelectedMenu;
      this.Data = this.NavigationInfo[0].below;
       this.RemainingParentMenu=this.FindParentNavigationMenu(this.SelectedMenu); 
               
    }

    /*let currentUrl = this._router.routerState.snapshot.url;
    if(currentUrl.length >1){
      let obj= new ContentNavigation().ManagePageRedirection(currentUrl.slice(1));
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);
    }*/
  }
  private FindParentNavigationMenu(selectedMenu: string) {
    
    let resultFirstLink = this.GlobalNavigationInfo.filter((item, index) => {
      return (item.title.trim() == selectedMenu);
    });
    let resultSecondLink = this.GlobalNavigationInfo.filter((item, index) => {
      return (item.title.trim() != selectedMenu);
    });
    let result=[];
    result.push(resultFirstLink[0]);
    result.push(resultSecondLink[0]);
    return result;
  }

  public ManageContentNavigation(data: any) {    
    this.ManageToggle();
    let obj = new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj, this._router, this._activatedRoute);
  }

  public ManageParentMenu(data: any){      
    this.OnMobileMenuSelect.emit(data);    
  }

  public ManageToggle() {
    if (typeof document !== 'undefined') {
      let toggleState = document.getElementById("togglenavigation");
      let toggleImage = document.getElementById("toggleimage");
      let secElementState = document.getElementById("sec-wrapper-navigation");

      if (toggleState.className == "c-navigation--default is-open") {
        document.getElementById("togglenavigation").className = "c-navigation--default";
      }
      if (toggleImage.className == "burger is-active") {
        document.getElementById("toggleimage").className = "burger";
      }
      if (secElementState.className == "c-sec-navigation--default is-menu-open") {
        document.getElementById("sec-wrapper-navigation").className = "c-sec-navigation--default";
      }

      //reset the classes to fix scroll issue for mobile view (has-no-scroll)
      document.getElementsByTagName('html')[0].className = "no-js";
      document.getElementsByTagName('body')[0].className = "";
    }
  }

  public defaultOnClick(){
    return false;
  } 
}
