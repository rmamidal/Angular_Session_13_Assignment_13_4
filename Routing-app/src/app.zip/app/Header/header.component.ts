import { Component, OnInit,Input } from '@angular/core';
import { HeaderService } from './header.service';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { ContentNavigation } from '../Model/contentnavigation.model';
import { ActivatedRoute, Router } from '@angular/router';
import { RedirectionService } from '../Service/redirection.service';
import { SubNavigationComponent } from './SubNavigation/subnavigation.component';


@Component({
  selector: 'header-component',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  providers: [HeaderService, RedirectionService]
})

export class HeaderComponent implements OnInit {
  @Input() isNotificationOpen: boolean = false; 
  GlobalNavigationInfo: any;
  SubNavigationData: any;
  IsInitiateSubNavigation: boolean = false;
  IsActiveClassVisible: boolean = true;
  SubNavigationComponentObj: SubNavigationComponent;  
  public CurrentParentMenu:string;
  public SearchText:string = "";
  constructor(private _service: HeaderService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private _redirectionService: RedirectionService
  ) {
    this.SubNavigationComponentObj = new SubNavigationComponent(this._router, this._activatedRoute, this._redirectionService);    
  }

  ngOnInit() {
    this.Init();
  }

  private Init() {
    this._service.FindGlobalNavigation().subscribe((data) => {
      this.GlobalNavigationInfo = data;      
      let currentUrl = this._router.routerState.snapshot.url.slice(1).toLowerCase();
      let isPersonal = this.IsUrlContainsPersonalLink(currentUrl);
      let isBusiness = this.IsUrlContainsBusinessLink(currentUrl);      
      if(isPersonal){
        this.ActivateSubNavigationOnLoad(this.GlobalNavigationInfo[0], 0);        
      }
      if(isBusiness){
        this.ActivateSubNavigationOnLoad(this.GlobalNavigationInfo[1], 1);
      }
      if(!isPersonal && !isBusiness){
        this.ActivateSubNavigationOnLoad(this.GlobalNavigationInfo[0], 0);
      }
      
    });
  }

  private IsUrlContainsPersonalLink(url:string):boolean{        
    let result:boolean = url.indexOf('personal') > -1;
    return result;
  }
  private IsUrlContainsBusinessLink(url:string):boolean{        
    let result:boolean = url.indexOf('business') > -1;
    return result;
  } 
  private FindSubNavigationData(selectedMenu:string,selectedIndex?: number) {
    return this.GlobalNavigationInfo.filter((item, index) => {
      return (item.title.trim() == selectedMenu);
    })
  }
  //used for re-initialize the component...
  public selected: string = '';
  OnMenuSelect(item, index?) {    
    if(item.external){
      this.ManageContentNavigation(item.uri);
    }
    else{      
      this.SubNavigationData = this.FindSubNavigationData(item.title.trim(),index);      
      this.selected = item.title; 
      this.ManageContentNavigation(item.alias);
      setTimeout(() => {
        this.IsInitiateSubNavigation = false;
      }, 0)
      setTimeout(() => {
        this.IsInitiateSubNavigation = true;
      }, 0)
    }
  }

  private ActivateSubNavigationOnLoad(item,index?){
    if(item.external){
      this.ManageContentNavigation(item.uri);
    }
    else{      
      this.SubNavigationData = this.FindSubNavigationData(item.title.trim(),index);      
      this.selected = item.title;       
      setTimeout(() => {
        this.IsInitiateSubNavigation = false;
      }, 0)
      setTimeout(() => {
        this.IsInitiateSubNavigation = true;
      }, 0)
    }
  }

  

  public MobileMenuSelect(data: any){
    this.OnMenuSelect(data);
  }

  public ManageContentNavigation(data: any) {         
    this.SubNavigationComponentObj.ManageToggle();
    let obj = new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj, this._router, this._activatedRoute);

  }
  public ReloadHomePage(){
    if(typeof window !== undefined){
      window.location.href = "";
    }
  }
  public RedirectToStore(){
    let storeUrl ="https://www.store.celcom.com.my/store/";
    let obj = new ContentNavigation().ManagePageRedirection(storeUrl);
    this._redirectionService.HandleNavigation(obj, this._router, this._activatedRoute); 
  }
  public RedirectToLogin(){
    let loginUrl="https://www.celcom.com.my/servicecenter/faces/oracle/webcenter/portalapp/pages/selfservice/slogin.jspx?_afrLoop=59561452172509&_afrWindowMode=0&_afrWindowId=null#%40%3F_afrWindowId%3Dnull%26_afrLoop%3D59561452172509%26_afrWindowMode%3D0%26_adf.ctrl-state%3D10gn7x4378_4";
    let obj = new ContentNavigation().ManagePageRedirection(loginUrl);
    this._redirectionService.HandleNavigation(obj, this._router, this._activatedRoute);
    
  }
  public defaultOnClick(){
    return false;
  }

  public OnSearchClick(){        
    if (typeof window !== 'undefined') {       
      localStorage.setItem('searchKey', this.SearchText);
      window.location.href="search";
    }
  } 
}
