import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import { HttpClient, HttpHeaders,HttpParams } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { RequestOptions, RequestOptionsArgs, Headers, URLSearchParams } from '@angular/http';
import {ElasticSearchRequestModel} from '../Model/elasticsearch.model'

@Injectable()
export class AppService {  

  constructor(private http: HttpClient) { 
  }
  // Fetch Resource
  get(endpoint: string){
    let _headers = new HttpHeaders();
    _headers.append("Content-Type","application/hal+json");
    return this.http.get("http://localhost:8080"+endpoint,{headers: _headers});
  	//return this.http.get(endpoint,{headers: _headers});
  }
  
  //To call external API's using POST method
  postROI(endpoint: string,data:any,token?:string){    
    let _headers = new HttpHeaders();
    let _httpHeader = _headers.append("Content-Type","application/json");
    if (token) { 
      _httpHeader = _headers.append("X-CSRF", token);
    } 
    let jsonData = data;    
    return this.http.post("http://localhost:8080"+endpoint,jsonData,{headers:_httpHeader});          
    //return this.http.post(endpoint,jsonData,{headers:_httpHeader});          
  }

  getElasticSearch(endpoint: string, searchParameter:ElasticSearchRequestModel){         
    let _headers = new HttpHeaders();
    _headers.append("Content-Type","application/hal+json");  
    const _queryStringParams = new HttpParams()
    .set("q",searchParameter.SearchTerm)
    .set("pretty",searchParameter.PrettyScript)
    .set("size",searchParameter.PageSize.toString())
    .set("from",searchParameter.PageIndex.toString());  
    return this.http.get(endpoint,{headers:_headers,params: _queryStringParams });
  }
  // Fetch Estore Resource
  getEstoreData(endpoint: string){
    let _headers = new HttpHeaders();
    _headers.append("Content-Type","application/hal+json");
    return this.http.get("http://localhost:8080"+endpoint,{headers: _headers});
    //return this.http.get(endpoint,{headers: _headers});
  }
  
   // Fetch Estore Resource
   postEstoreData(endpoint: string){
    let _headers = new HttpHeaders();
    _headers.append("Content-Type","application/hal+json");
    return this.http.post("http://localhost:8080"+endpoint,{headers: _headers});
    //return this.http.get(endpoint,{headers: _headers});
  }
}