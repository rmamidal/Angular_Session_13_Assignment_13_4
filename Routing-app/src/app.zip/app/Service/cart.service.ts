import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseService } from '../base.service';
import { AppService } from '../Service/app.service';
import { Cart } from '../Model/cart.model';
import { CartItem } from '../Model/cart-item.model';

const CART_KEY = "cart";

@Injectable()
export class CartService extends BaseService {

	constructor(private _service:AppService) {
		super();
	}

  	public Find(apiURL:string):Observable<any[]> {  
      	let url = apiURL.replace(/[+_]/g,'%2B');
      	let options = this.GenerateHeader();    
      	return this._service
      	.getEstoreData(url)
      	.map((response:any) => {
          return response
      	})        
    }
    
    public PostData(apiURL:string):Observable<any[]> {  
        let url = apiURL.replace(/[+_]/g,'%2B');
        let options = this.GenerateHeader();    
        return this._service
        .postEstoreData(url)
        .map((response:any) => {
        return response
        })        
  }

	public addProductToCart(product:any, quantity: number): void {

        let apiUrl:string = "/rest/V1/addtocart/"+product.sku;      
		this.PostData(apiUrl.trim()).subscribe(      
		(response: any)=> {

        });

        const cart = this.retrieveCart();
        let item = cart.items.find((p) => p.sku === product.sku);
        
        if (item === undefined) {
            item = new CartItem();
            item.sku = product.sku;
            cart.items.push(item);
        }
        item.quantity += quantity;
        item.itemTotal = item.quantity*item.price;
        cart.grossTotal = cart.items
            .map((item) => item.quantity * item.price)
            .reduce((previous, current) => previous + current, 0);
        this.save(cart);
    }
    
    public retrieveCart(): Cart {

        let apiUrl:string = "/rest/V1/viewcart";      
		this.Find(apiUrl.trim()).subscribe(      
		(response: any)=> {

        });

        const cart = new Cart();
        const storedCart = localStorage.getItem(CART_KEY);
        if (storedCart) {
            cart.setCart(JSON.parse(storedCart));
        }
        return cart;
    }

    private save(cart: Cart): void {
        localStorage.setItem(CART_KEY, JSON.stringify(cart));
    }

    public removeProductFromCart(product:any){
        const cart = this.retrieveCart();
        let item = cart.items.find((p) => p.sku === product.sku);
        if (item != undefined) {
            item.quantity = 0;
            cart.items = cart.items.filter((cartItem) => cartItem.quantity > 0);
            
        }
        
        cart.grossTotal = cart.items
        .map((item) => item.quantity * item.price)
        .reduce((previous, current) => previous + current, 0);
        this.save(cart);
    }
}
