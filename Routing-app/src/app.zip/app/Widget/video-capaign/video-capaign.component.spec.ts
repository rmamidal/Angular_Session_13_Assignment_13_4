import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VideoCapaignComponent } from './video-capaign.component';

describe('VideoCapaignComponent', () => {
  let component: VideoCapaignComponent;
  let fixture: ComponentFixture<VideoCapaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VideoCapaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VideoCapaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
