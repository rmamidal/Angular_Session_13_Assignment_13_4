import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { ElementRef, ViewChild } from '@angular/core';
import { AppService } from '../../Service/app.service';
import {BaseComponent} from '../../base.component';

@Component({
  moduleId: module.id,
  selector: 'video-gallery',
  templateUrl: './video-capaign.component.html',
  styleUrls: ['./video-capaign.component.css']
})
export class VideoCapaignComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public carouselTileItems: Array<any>;
  public carouselTile: NguCarousel;
  public player: YT.Player;
  public change_url: string;
  public current_url: string;
  public id: string;
  public videoId: string;
  public iframewidth: number;
  public iframeHieght: number;
  public btnDisplay: string = "visible";
  public leftorRight: string = "block";
  public rightBtn: number = 1;
  public selectedIndex: number = 0;
  public border: boolean = false;
  public banerDisplay: boolean = true;
  public mouseindex: number;
  public videoGalleryObj: any;
  public videoTitle: string;
  public videoBgColor: string;
  public fillBg:string;
  public desktopImage:any;
  public mobileImage:any;

  public VideoCampignResponse = null;

  constructor(private _service:AppService) {
    super();
  }
  
  public mouseenter(index: number) {
    this.mouseindex = index;
  }
  public mouseleave() {
    this.mouseindex = -1;
  }
  public select(index: number) {
    this.selectedIndex = index;
  }

  @ViewChild('youplayer') elementView: ElementRef;
  viewHeight: number;
  public savePlayer(player) {
    this.player = player;
    this.iframewidth = this.elementView.nativeElement.offsetWidth;
    this.iframeHieght = 420;
    if(typeof window!= undefined){
      if (window.innerWidth < 768 && window.innerWidth > 500) {
        this.iframeHieght = 300;
      }
      if (window.innerWidth <= 500) {
        this.iframeHieght = 180;
      }
      this.player.setSize(this.iframewidth, this.iframeHieght);
    }
  }
  getUrl() {
    if (this.selectedIndex == 0 && this.banerDisplay) {
      if(typeof window !== undefined){
        if(window.innerWidth > 767){
          return 'url(' + this.ApiUrl+this.desktopImage.imageUrl + ')';
        }
        else{
          return 'url(' + this.ApiUrl+this.mobileImage.imageUrl + ')';
        }
      }
    } else {
      return null;
    }
  }
  getIconUrl(ev) {
    if (ev == 2) {
      return 'url(' + this.videoGalleryObj.nextBtn + ')';
    } else {
      return 'url(' + this.videoGalleryObj.backBtn + ')';
    }
  }
  public onStateChange(event) {


    if (event.data == 0) {

      var index = this.carouselTileItems.map(function (e) { return e.videoId; }).indexOf(this.videoId);
      if (index < this.carouselTileItems.length - 1) {
        this.player.cueVideoById(this.carouselTileItems[index + 1].videoId);
        this.player.playVideo();
        this.select(index + 1);
        this.videoId = this.carouselTileItems[index + 1].videoId;
      }

    }
    if (event.data !== 1 && event.data !== 3 && this.selectedIndex == 0) {
      this.btnDisplay = "visible";
      this.banerDisplay = true;

    } else {
      this.btnDisplay = "hidden";
      this.banerDisplay = false;
    }
  }

  public onResize(event) {
    this.iframewidth = this.elementView.nativeElement.offsetWidth;
    this.iframeHieght = 420;
    if(this.player != undefined) {
      this.player.setSize(this.iframewidth, this.iframeHieght);
      if(typeof window !== undefined){
        if (window.innerWidth < 768 && window.innerWidth > 500) {
          this.iframeHieght = 300;
          this.leftorRight = "none";
        }
        if (window.innerWidth <= 500) {
          this.iframeHieght = 180;
          this.leftorRight = "none";
        }
        this.player.setSize(this.iframewidth, this.iframeHieght);
      }
    }
  }
  ngOnInit() {
    let url = "/"+this.data.Api+'?_format=hal_json';
    this._service.get(url).subscribe(
      (response) => {
        this.VideoCampignResponse = response;
        this.videoGalleryObj = {
          "nextBtn": "../../../../assets/img/next.png",
          "backBtn": "../../../../assets/img/back1.png",
          "videobackgroud": "#005069",
          "ploygonBg":"#fff"
        }
        this.desktopImage = this.VideoCampignResponse.desktopImage;
        this.mobileImage = this.VideoCampignResponse.mobileImage;
        this.fillBg=this.videoGalleryObj.ploygonBg;
        this.videoBgColor = this.videoGalleryObj.videobackgroud;
        this.videoTitle = this.VideoCampignResponse.campaignTitle;
        this.carouselTileItems = this.VideoCampignResponse.Items;
        this.id = this.carouselTileItems[0].videoId;
        this.videoId = this.id;
        if (this.carouselTileItems.length > 2) {
          this.carouselTile = {
            grid: { xs: 2, sm: 3, md: 3, lg: 3, all: 0 },
            slide: 3,
            speed: 200,
            animation: 'lazy',
            point: {
              visible: true,
              pointStyles: `
            .ngucarouselPoint li:only-child{
                display:none;
             }  
            .ngucarouselPoint {
              list-style-type: none;
              text-align: center;
              padding: 8px;
              margin: 0;
              white-space: nowrap;
              overflow: auto;
              box-sizing: border-box;
            }
            .ngucarouselPoint li {
              display: inline-block;
              border-radius: 50%;
              
              background:#7F7F7F7F;
              padding: 4px;
              margin: 0 3px;
              transition-timing-function: cubic-bezier(.17, .67, .83, .67);
              transition: .4s;
            }
            .ngucarouselPoint li.active {
                background: #009ADE;
                transform: scale(1.2);
            }
          `
            },
            load: 2,
            touch: false,
            easing: 'ease'
          }
    
    
    
        } else {
          this.carouselTile = {
            grid: { xs: 2, sm: 3, md: 3, lg: 3, all: 0 },
            slide: 1,
            speed: 200,
            animation: 'lazy',
            point: {
              visible: false,
    
            },
            load: 1,
            touch: false,
            easing: 'ease'
          }
    
    
        }
        if (this.carouselTileItems.length == 1) {
          document.getElementById('carDiv').style.display = "none"
        }
    
        if (this.carouselTileItems.length == 2) {
          this.rightBtn = 0;
    
        }
      } 
    );
    /*
    *videoGalleryObj: video gallery configuration obejct.FInd the description below for respective properties
    * videoTitle:provide Video title
    * imageBaner: provide baner image path,Dimension : 1024px X420px,Image type: png,jpg
    * nextBtn: provide next button image path,Dimension : 32px X32px,Image type: png,jpg
    * backBtn: provide back button image path,,Dimension : 32px X32px,Image type: png,jpg
    *videobackgroud: provide video background color 
    *galleryItems: provide the video id,videotitle,image from youtube,views,video Description
    *ploygonBg: provide the backgroung color of bottom default #fff is used as per vd but in CMS it can be changed
    */
  }

  public carouselTileLoad(evt: any) {


  }

  public loadVideoById(event) {
    var target = event.currentTarget;
    this.videoId = target.id;
    this.player.cueVideoById(this.videoId);
    this.player.playVideo();
  }

  public play() {
    this.player.playVideo();
  }

}
