import { Component, OnInit, ViewContainerRef, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { ProductBannerTextLeftService } from "./product-banner-text-left.service";
import { AppWidgetComponent } from '../../Model/app.widget.component';
import { BaseComponent } from '../../base.component';
import { ContentNavigation } from '../../Model/contentnavigation.model';
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../Service/redirection.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-product-banner-text-left',
  templateUrl: './product-banner-text-left.component.html',
  styleUrls: ['./product-banner-text-left.component.css'],
  providers: [ RedirectionService, ProductBannerTextLeftService ]
})
export class ProductBannerTextLeftComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public ProductBannerResponse = null;
  public deskImage = null;  
  public TextDisplay : number = null;
  public TitleSafeHtml;
  public SubTitleSafeHtml;
  public DisplayClass;

  constructor(private sanitizer: DomSanitizer, private _ProductBannerTextLeftService:ProductBannerTextLeftService,public viewContainerRef: ViewContainerRef,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) {
      super();    
  }
 
  ngOnInit() {
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api != undefined){           
      let url = "/"+ this.data.Api + "?_format=hal_json";
      this._ProductBannerTextLeftService.Find(url).subscribe(
      (response:any)=>{
        this.ProductBannerResponse=response.Items;

        this.ProductBannerResponse.forEach((item:any) => {    
          if((response.Items.length == 1) && (item.TextDisplay == 'Left')){
            this.TextDisplay = 1;
          }
          else if((response.Items.length == 1) && (item.TextDisplay == 'Centre')){
            this.TextDisplay = 2;
          }
          else if(response.Items.length > 1) {
            //this.TextDisplay = 3;
            if(item.TextDisplay == 'Left') {
              this.DisplayClass = "product-banner-left-layout";
              item.TextDisplayClass = "product-banner-left-layout";
            }
            if(item.TextDisplay == 'Centre') {
              this.DisplayClass = "product-banner-center-layout";
              item.TextDisplayClass = "product-banner-center-layout";
            }
          }

          item.DesktopImage = this.ApiUrl + item.DesktopImage;  
          item.MobileImage = this.ApiUrl + item.MobileImage;  
          item.TitleSafeHtml = this.sanitizer.bypassSecurityTrustHtml(item.Title);
          item.SubTitleSafeHtml = this.sanitizer.bypassSecurityTrustHtml(item.Subtitle);
        });   
      });
    }
  }
  public ManageContentNavigation(data:any){
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);  
  }
}