import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {StarRatingService} from "./starrating.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'starrating-component',
  templateUrl: './starrating.component.html',
  providers:[StarRatingService,RedirectionService]
})
export class StarRatingComponent extends BaseComponent implements AppWidgetComponent {
  @Input() data: any;
  public StarRatingResponse = null;

    constructor(private starratingservice:StarRatingService,
      private _router:Router,
      private _activatedRoute:ActivatedRoute,
      private _redirectionService:RedirectionService
    ){
      super();
    }

    ngOnInit(){ 
      this.Init();
    }

    private Init() {      
      if(this.data && this.data.Api != undefined){
        let apiUrl = "/" + this.data.Api + "?_format=hal_json";
        this.starratingservice.Find(apiUrl).subscribe(
          (response)=>{
            this.StarRatingResponse = response['Items'][0];            
            this.StarRatingResponse.field_background_image = this.ApiUrl + this.StarRatingResponse.field_background_image;            
          });
      }
    }

    public ManageContentNavigation(data:any){   
      let obj= new ContentNavigation().ManagePageRedirection(data);
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
   }

   public defaultOnClick(){
    return false;
  } 
}