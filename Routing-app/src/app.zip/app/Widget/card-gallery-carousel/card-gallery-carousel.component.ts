import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-card-gallery-carousel',
  templateUrl: './card-gallery-carousel.component.html',
  styleUrls: ['./card-gallery-carousel.component.css']
})
export class CardGalleryCarouselComponent implements OnInit {
  @Input() data: any;
  constructor() { }

  ngOnInit() {
  }

}
