import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { ProductBannerMegaService } from "./product-banner-mega.service";
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'
@Component({
  selector: 'product-banner-mega',
  templateUrl: './product-banner-mega.component.html',
  styleUrls: ['./product-banner-mega.component.css'],
  providers: [ProductBannerMegaService,RedirectionService]
})

export class ProductBannerMegaComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public ProductBannerMegaResponse: any;
  public planTableData:any;
  public planTable:any;
  public innerPlanTable:any;
  public PlanTableHidden:any;

  constructor(private  productbannermegaservice: ProductBannerMegaService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) {
      super();
    this.planTable = [];
    this.innerPlanTable = [];
  }

  ngOnInit() {
    this.Init();
  }

  private Init() {  
    if(this.data && this.data.Api != undefined){
          let that = this;
        let apiUrl = "/" + this.data.Api + "?_format=hal_json";
          this.productbannermegaservice
            .getData(apiUrl)
            .subscribe((data:  any) => { 
              this.ProductBannerMegaResponse = data.Items[0];
              this.ProductBannerMegaResponse.BannerImage = this.ApiUrl+ this.ProductBannerMegaResponse.BannerImage;      
                let typeOfData = typeof (this.data.PlanTable);          
                if(typeOfData == "object"){                              
                  let planTableUrl:string = "/" + this.data.PlanTable.Api + "?_format=hal_json"; 
                  if(this.data.PlanTable.Api != undefined)
                  {
                    this.productbannermegaservice.FindTableWithoutHeadingInfo(planTableUrl)          
                    .subscribe((response:any) => {              
                      this.planTableData = response.Items[0]; //this.data.PlanTable; 
                      //need to add even the this.data.PlanTable=>"",to handle blank table                   
                    
                      this.planTable.push(this.planTableData);            
                      this.planTable.forEach((item:any,index) => {
                        if(item!=""){
                          item.Id = index;
                          item.HrefId="rm-"+index;
                          item.AtrHref="#rm-"+index;
                          item.TableInfo.forEach((innerItem:any) => {
                            innerItem.fieldIcon=this.ApiUrl+innerItem.fieldIcon;
                          });
                          //item.fieldIcon=this.data.PlanTable.Api+item.fieldIcon;
                        }
                      });           
                      this.PlanTableHidden = "visible";              
                  });
                }
                }
                else{            
                  this.planTable.push(this.ProductBannerMegaResponse);            
                  this.planTable.forEach((item:any,index) => {
                    if(item!=""){
                      item.Id = index;
                      item.HrefId="rm-"+index;
                      item.AtrHref="#rm-"+index;
                    }
                  });  
                  this.PlanTableHidden = "hidden";
                }                    
            });
    }
  }

  private ManageTabelWithoutHeading(){

  }
  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }




}
