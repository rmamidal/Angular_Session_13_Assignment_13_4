import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { PlanDeviceComparisonService} from "./plan-device-comparison.service";
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'
import { CompareProductService } from '../../../Service/compareproduct.service';
import { CartService } from '../../../Service/cart.service';


@Component({
  selector: 'app-plan-device-comparison',
  templateUrl: './plan-device-comparison.component.html',
  styleUrls: ['./plan-device-comparison.component.css'],
  providers:[PlanDeviceComparisonService,RedirectionService,CompareProductService,CartService]
})
export class PlanDeviceComparisonComponent extends BaseComponent implements OnInit {
	public productList:any;
	public productListDetails = [];
	constructor(private _service:PlanDeviceComparisonService,
		private cartService:CartService,
		private compProductService: CompareProductService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
	}

	ngOnInit() {
		this.Init();
	}

	Init() {
		this.productList = this.compProductService.retrieveProduct();
		//alert(JSON.parse(this.productList));
		this.productList.noOfProds.forEach((item:any,index) => { 
			// Providing the plan json
			let url = '/rest/V1/products/' + item.sku;
			this._service.Find(url).subscribe(
			  (response:any)=> {
				response.custom_attributes.forEach((itemDetails:any) => {
				  switch(itemDetails.attribute_code) {
					case "device_model": 
					this.productListDetails.unshift({device_model:itemDetails.value});
					break;
					case "knowmoretext": 
					this.productListDetails.unshift({knowmoretext:itemDetails.value});
					  break;
					case "dimension": 
					 this.productListDetails.unshift({dimension:itemDetails.value});
					  break;
					case "backgroundcolor": 
					  this.productListDetails.unshift({weight:itemDetails.value});
					break;
					case "screen_size": 
					this.productListDetails.unshift({screen_size:itemDetails.value});
					break;
					case "chip_processor": 
						this.productListDetails.unshift({chip_processor:itemDetails.value});
					break;
					case "splash_water_dust_resistant": 
					let swdr = itemDetails.value? "Yes": "No";
					this.productListDetails.unshift({splash_water_dust_resistant:swdr});
					break;
					case "talk_time": 
					this.productListDetails.unshift({talk_time:itemDetails.value});
					break;
					case "standby_time": 
					this.productListDetails.unshift({standby_time:itemDetails.value});
					break;
					case "sim_type": 
					this.productListDetails.unshift({sim_type:itemDetails.value});
					break;
				  }
			  });
		  });
		});
	}

	addDeviceToCart(product:any) {
		this.cartService.addProductToCart(product,1);
		alert(product.sku+" added to cart");
	}

	removeCompareProduct(product:any) {
		this.compProductService.removeProductFromCompare(product);
		this.productList = this.compProductService.retrieveProduct();
		this.productListDetails = [];
		this.productList.noOfProds.forEach((item:any,index) => { 
			// Providing the plan json
			let url = '/rest/V1/products/' + item.sku;
			this._service.Find(url).subscribe(
			  (response:any)=> {
				response.custom_attributes.forEach((itemDetails:any) => {
				  switch(itemDetails.attribute_code) {
					case "device_model": 
					this.productListDetails.unshift({device_model:itemDetails.value});
					break;
					case "knowmoretext": 
					this.productListDetails.unshift({knowmoretext:itemDetails.value});
					  break;
					case "dimension": 
					 this.productListDetails.unshift({dimension:itemDetails.value});
					  break;
					case "backgroundcolor": 
					  this.productListDetails.unshift({weight:itemDetails.value});
					break;
					case "screen_size": 
					this.productListDetails.unshift({screen_size:itemDetails.value});
					break;
					case "chip_processor": 
						this.productListDetails.unshift({chip_processor:itemDetails.value});
					break;
					case "splash_water_dust_resistant": 
					let swdr = itemDetails.value? "Yes": "No";
					this.productListDetails.unshift({splash_water_dust_resistant:swdr});
					break;
					case "talk_time": 
					this.productListDetails.unshift({talk_time:itemDetails.value});
					break;
					case "standby_time": 
					this.productListDetails.unshift({standby_time:itemDetails.value});
					break;
					case "sim_type": 
					this.productListDetails.unshift({sim_type:itemDetails.value});
					break;
				  }
			  });
		  });
		});
	  }

	public ManageContentNavigation(data:any){              
		let obj= new ContentNavigation().ManagePageRedirection(data);
		this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
	}

}
