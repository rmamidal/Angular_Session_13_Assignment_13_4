import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiviceFilterComponent } from './divice-filter.component';

describe('DiviceFilterComponent', () => {
  let component: DiviceFilterComponent;
  let fixture: ComponentFixture<DiviceFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiviceFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiviceFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
