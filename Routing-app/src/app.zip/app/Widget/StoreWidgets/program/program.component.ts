import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { ProgramService } from "./program.service";
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'


@Component({
  selector: 'store-program',
  templateUrl: './program.component.html',
  styleUrls: ['./program.component.css'],
  providers:[ProgramService,RedirectionService]
})
export class ProgramComponent extends BaseComponent implements OnInit {
	programs = null;
	constructor(private programService: ProgramService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
	}

	ngOnInit() {
		this.Init();
	}

	Init() {
		let apiUrl:string = "/api/imageCardOverlay/870+871+872+873+874+875+876";      
		this.programService.Find(apiUrl.trim()).subscribe(      
		(response: any)=>{  
			this.programs = response.Items;
		});
	}

	public ManageContentNavigation(data:any){              
		let obj= new ContentNavigation().ManagePageRedirection(data);
		this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
	}

}
