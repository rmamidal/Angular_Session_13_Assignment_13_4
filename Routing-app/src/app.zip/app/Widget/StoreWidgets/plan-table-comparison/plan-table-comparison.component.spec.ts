import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanTableComparisonComponent } from './plan-table-comparison.component';

describe('PlanTableComparisonComponent', () => {
  let component: PlanTableComparisonComponent;
  let fixture: ComponentFixture<PlanTableComparisonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanTableComparisonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanTableComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
