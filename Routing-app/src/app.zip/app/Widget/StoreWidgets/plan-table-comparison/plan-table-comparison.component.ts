import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {AppWidgetComponent} from '../../../Model/app.widget.component';
import {BaseComponent} from '../../../base.component';
import {ContentNavigation} from '../../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../../Service/redirection.service'
import { PlanTableComparisionService} from './plan-table-comparison.service'

@Component({
  selector: 'app-plan-table-comparison',
  templateUrl: './plan-table-comparison.component.html',
  styleUrls: ['./plan-table-comparison.component.css'],
  providers:[RedirectionService, PlanTableComparisionService]
})
export class PlanTableComparisonComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public TableComparisonResponse = null;

  constructor(
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService,
    private _service:PlanTableComparisionService
  ){
    super();
   
  }

  ngOnInit(){
    this.Init();
  }

  private Init() {     
  
      if(this.data && this.data.Api != undefined){  
        // Commented Drupal service e.g: /api/tableComparison/171+234+236+237+238?_format=hal_json
        //let url = "/"+ this.data.Api + "?_format=hal_json"; 
        //let url = './assets/estore/plan_list.json';  // Tesing with Sample magento Json
        let url = "/rest/V1/categories/4/products";
        this._service.Find(url).subscribe(
          (response:any)=>{   
            // Iterating Sample magento Json.
            this.TableComparisonResponse=response;             
            this.TableComparisonResponse.forEach((itemParent:any,index) => { 
              // Providing the plan json
              let url2 = '/rest/V1/products/' + itemParent.sku;
              this._service.Find(url2).subscribe(
                (response:any)=> {
                  itemParent.KeyText = "RM " +response.price;
                  itemParent.custom_attributes = response.custom_attributes;
                  itemParent.custom_attributes.forEach((item:any) => {
                    switch(item.attribute_code) {
                      case "plan_data": 
                      itemParent.KeyFiguresText = item.value;
                      break;
                      case "knowmoretext": 
                        itemParent.knowMoreText = item.value;
                        break;
                      case "buynowtext": 
                        itemParent.BuynowText = item.value;
                        break;
                      case "indicatorclass": 
                        itemParent.IndicatorClass = 'is-level-' + item.value.toLowerCase();
                        break;
                      case "backgroundcolor": 
                        itemParent.BackgroundColor = 'is-bg-color-' + item.value;
                        break;
                      case "description": 
                        itemParent.TableInfo= item.value;
                        break;
                        case "url_key": 
                        itemParent.BuynowLink = 'store/plans/' + itemParent.sku;
                        break;
                    }
                  });
                });
  
              // Adding sample data which is not in Json output.
              itemParent.ProductText = itemParent.sku;
              //itemParent.TableInfo.innerHtml = itemParent.TableInfoUnformatted;
              itemParent.AtrHref="#rm-"+index;
            });
          });
        }
  
  }

  public ManageContentNavigation(data:any){
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
 }
}
