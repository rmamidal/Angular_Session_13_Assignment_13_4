import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { PlanBannerMegaService } from "./plan-banner-mega.service";
import {BaseComponent} from '../../../base.component';
import {ContentNavigation} from '../../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../../Service/redirection.service'
@Component({
  selector: 'plan-banner-mega',
  templateUrl: './plan-banner-mega.component.html',
  styleUrls: ['./plan-banner-mega.component.css'],
  providers: [PlanBannerMegaService,RedirectionService]
})

export class PlanBannerMegaComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public ProductBannerMegaResponse: any;
  public planTableData:any;
  public planTable:any;
  public innerPlanTable:any;
  public PlanTableHidden:any;

  constructor(private  productbannermegaservice: PlanBannerMegaService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) {
      super();
    this.planTable = [];
    this.innerPlanTable = [];
  }

  ngOnInit() {
    this.Init();
  }

  private Init() {  
    if(this.data && this.data.Api != undefined){
          let that = this;
        let apiUrl = "/" + this.data.Api + "?_format=hal_json";
          this.productbannermegaservice
            .getData(apiUrl)
            .subscribe((data:  any) => { 
              localStorage.setItem('plan',JSON.stringify(data));  
              this.ProductBannerMegaResponse = data.Items[0];
              this.ProductBannerMegaResponse.BannerImage = this.ApiUrl+ this.ProductBannerMegaResponse.BannerImage;      
                let typeOfData = typeof (this.data.PlanTable);          
                if(typeOfData == "object"){                              
                  let planTableUrl:string = this.data.PlanTable.Api; 
                  if(this.data.PlanTable.Api != undefined)
                  {
                    this.productbannermegaservice.FindTableWithoutHeadingInfo(planTableUrl)          
                    .subscribe((response:any) => {              
                      this.planTableData = response; //this.data.PlanTable; 
                      //need to add even the this.data.PlanTable=>"",to handle blank table                   
                      //this.planTable.push(this.planTableData);
                        this.planTable['ProductText']= this.planTableData.sku;  
                        this.planTableData.custom_attributes.forEach((item:any) => {
                          switch(item.attribute_code) {
                           case "device_price_now": 
                            this.planTable['KeyText']= 'RM' + item.value;
                            break;
                            case "plan_data": 
                            this.planTable['KeyFiguresText']= item.value;
                            break;
                            case "knowmoretext": 
                            this.planTable['knowMoreText']= item.value;
                              break;
                            case "buynowtext": 
                            this.planTable['BuynowText']= item.value;
                              break;
                            case "indicatorclass": 
                            this.planTable['IndicatorClass']= 'is-level-' + item.value.toLowerCase();
                              break;
                            case "backgroundcolor": 
                            this.planTable['BackgroundColor']= 'is-bg-color-' + item.value;
                              break;
                            case "description": 
                            this.planTable['TableInfo']= item.value;
                              break;
                          }
                        });
                      this.PlanTableHidden = "visible";              
                  });
                }
                }
                else{            
                  this.planTable.push(this.ProductBannerMegaResponse);            
                  this.planTable.forEach((item:any,index) => {
                    if(item!=""){
                      item.Id = index;
                      item.HrefId="rm-"+index;
                      item.AtrHref="#rm-"+index;
                    }
                  });  
                  this.PlanTableHidden = "hidden";
                }                    
            });
    }
  }

  private ManageTabelWithoutHeading(){

  }
  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
}
