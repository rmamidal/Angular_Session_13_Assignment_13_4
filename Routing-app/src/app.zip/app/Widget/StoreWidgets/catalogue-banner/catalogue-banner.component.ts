import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { CatalogueBannerService } from "./catalogue-banner.service";
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'


@Component({
  selector: 'store-catalogue-banner',
  templateUrl: './catalogue-banner.component.html',
  styleUrls: ['./catalogue-banner.component.css'],
  providers:[CatalogueBannerService,RedirectionService]
})
export class CatalogueBannerComponent extends BaseComponent implements OnInit {

	constructor(private catalogueBannerService: CatalogueBannerService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
	}

	ngOnInit() {

	}

	Init() {

	}

	public ManageContentNavigation(data:any){              
		let obj= new ContentNavigation().ManagePageRedirection(data);
		this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
	}

}
