import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { TopThreeService } from "./top-three.service";
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'
import { CartService } from '../../../Service/cart.service';
import { CompareProductService } from '../../../Service/compareproduct.service';

@Component({
  selector: 'store-top-three',
  templateUrl: './top-three.component.html',
  styleUrls: ['./top-three.component.css'],
  providers:[TopThreeService,RedirectionService,CartService,CompareProductService]
})
export class TopThreeComponent extends BaseComponent implements OnInit {
	topThree = null;
	constructor(private topThreeService: TopThreeService,
		private cartService:CartService,
		private compProductService: CompareProductService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
	}

	ngOnInit() {
		this.Init();
	}

	Init() {
		let apiUrl:string = "/rest/V1/categories/7/products";      
		this.topThreeService.Find(apiUrl.trim()).subscribe(      
		(response: any)=> {  
			/* manage api limitation*/
			var resultData = response;
			resultData.forEach((item:any,index) => {
				item.price = 300;
				let apiUrl:string = "/rest/V1/products/"+item.sku;
				this.topThreeService.Find(apiUrl.trim()).subscribe(      
					(response: any)=> { 
						item.id = response.id;
						response.custom_attributes.forEach((attribute:any,index) => {
							if(attribute.attribute_code == 'brand') {
								item.brand = attribute.value;
							}
						});
					this.topThree = resultData; 
					
				});
			});
		});
	}

	addDeviceToCart(product:any) {
		this.cartService.addProductToCart(product,1);
		alert(product.sku+" added to cart");
	}

	public addToCompare(item:any) {
		this.compProductService.addProductToCompare(item);
	}

	public ManageContentNavigation(data:any){              
		let obj= new ContentNavigation().ManagePageRedirection(data);
		this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
	}
}
