import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../../base.service';

@Injectable()
export class HeroBannerRightImageService extends BaseService  {
    constructor(private _http:Http){
        super();
    }

    public Find():Observable<any[]>{
        let url= this.BaseUrl + 'herobannerresponse.json';    
        return this._http
        .get(url)
        .map((response:any) => {
            return response
        })        
    } 
}