import { Injectable } from '@angular/core';
import { Http, RequestOptionsArgs, RequestOptions, Headers } from "@angular/http";
import { Observable } from 'rxjs/Rx';
import { NgForm } from '@angular/forms';
import "rxjs/add/operator/map";
import { BaseService } from '../../base.service';
import { AppService } from '../../Service/app.service';
import * as environment from '../../../../environment.json';

@Injectable()
export class RoiBusinessService extends BaseService {
  constructor(private _http: Http, private _service: AppService) {
    super();
  }
  public submitBizForm(retailForm: NgForm): Observable<any> {
    let url = (<any>environment).roiFormSubmission;
    let username = (<any>environment).APIGWuserName;
    let password = (<any>environment).APIGWpwd;
    let createActivityReq: {};
    let _headers = new Headers();

    _headers.append("Authorization", "Basic " + btoa(username + ":" + password));
    _headers.append('Content-Type', 'application/json');
    _headers.append('Accept', 'application/json');
    _headers.append('Access-Control-Allow-Credentials', 'true');
    let options = new RequestOptions({ headers: _headers });

    createActivityReq = JSON.stringify(retailForm);
    return this._http
      .post(url, createActivityReq, options).map((res) => {
        res.json()

      })

  }

  private ApiEndPoint = "/api/digitalportal/v1/createActivity";
  public PostROIFormData(data: any) {
    let body = {
      "createActivityReq": {
        "customerName": data.customerName,
        "email": data.email,
        "mobileNo": data.mobileNo,
        "alternateContact": data.alternateContact,
        "natureOfBusiness": data.businesstype,
        "id": data.businessregistRationDesc,
        "interestedIn": "interestIn",
        "companyName": data.companyName,
        "state": data.state,
        "comments": data.comments,
        "type": "Appointment",
        "category": "Biz",
        "source": "Portal",
      }
    };
    let details = JSON.stringify(body);
    return this._service.postROI(this.ApiEndPoint, details);
  }
}
