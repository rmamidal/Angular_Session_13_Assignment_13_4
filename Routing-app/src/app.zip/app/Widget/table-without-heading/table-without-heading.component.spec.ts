import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableWithoutHeadingComponent } from './table-without-heading.component';

describe('TableWithoutHeadingComponent', () => {
  let component: TableWithoutHeadingComponent;
  let fixture: ComponentFixture<TableWithoutHeadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableWithoutHeadingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableWithoutHeadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
