import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { DetailBannerTextCenterService } from "./detail-banner-text-center.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'app-detail-banner-text-center',
  templateUrl: './detail-banner-text-center.component.html',
  styleUrls: ['./detail-banner-text-center.component.css'],
  providers:[ DetailBannerTextCenterService, RedirectionService ]
})
export class DetailBannerTextCenterComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public DetailBannerTextCenterResponse = null;
  public DetailBannerTextCenterParentResponse = null;
  public backgroundImage:any = null;
  
  constructor(private _DetailBannerTextCenterService:DetailBannerTextCenterService, public viewContainerRef: ViewContainerRef,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) {
    super();    
  }
 
  ngOnInit() {
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api != undefined){
    let url = "/"+ this.data.Api + "?_format=hal_json";
    this.DetailBannerTextCenterParentResponse = this.data;
    this._DetailBannerTextCenterService.Find(url).subscribe(
      (response:any)=>{        
        this.DetailBannerTextCenterResponse=response.Items[0];
        this.backgroundImage = this.ApiUrl + this.DetailBannerTextCenterResponse.BannerImage;
      });
    }
  }
  public ManageContentNavigation(data:any){ 
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);  
  }
}