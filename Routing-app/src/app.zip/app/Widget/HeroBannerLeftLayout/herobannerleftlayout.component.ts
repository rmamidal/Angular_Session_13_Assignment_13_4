import { Component,OnInit,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {HeroBannerLeftLayoutService} from "./herobannerleftlayout.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'herobanner-leftlayout-component',
  templateUrl: './herobannerleftlayout.component.html',
  providers: [HeroBannerLeftLayoutService]
})

export class HeroBannerLeftLayoutComponent extends BaseComponent {
  @Input() data: any;
  public HeroLeftLayoutResponse = null;

  constructor(private heroleftlayoutservice:HeroBannerLeftLayoutService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService
  ){
    super();
  }

  ngOnInit(){
    this.Init();
  }

  private Init() {    
    this.HeroLeftLayoutResponse = this.data;    
  }

  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
 }
}