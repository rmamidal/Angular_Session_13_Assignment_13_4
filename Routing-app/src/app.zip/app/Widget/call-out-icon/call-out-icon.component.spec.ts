import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CallOutIconComponent } from './call-out-icon.component';

describe('CallOutIconComponent', () => {
  let component: CallOutIconComponent;
  let fixture: ComponentFixture<CallOutIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallOutIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallOutIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
