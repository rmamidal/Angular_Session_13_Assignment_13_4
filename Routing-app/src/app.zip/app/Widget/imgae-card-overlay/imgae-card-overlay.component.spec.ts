import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImgaeCardOverlayComponent } from './imgae-card-overlay.component';

describe('ImgaeCardOverlayComponent', () => {
  let component: ImgaeCardOverlayComponent;
  let fixture: ComponentFixture<ImgaeCardOverlayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImgaeCardOverlayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImgaeCardOverlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
