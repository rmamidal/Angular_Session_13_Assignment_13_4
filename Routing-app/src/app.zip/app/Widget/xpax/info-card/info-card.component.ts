import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseComponent } from '../../../base.component';
import { DomSanitizer } from '@angular/platform-browser';
import { ContentNavigation } from '../../../Model/contentnavigation.model';
import { ActivatedRoute, Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service';

@Component({
  selector: 'info-card',
  templateUrl: './info-card.component.html',
  styleUrls: ['./info-card.component.css', '../../../../assets/css/bootstrap.min.css']
})
export class InfoCardComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  cards: any;
  desktopBg: any;
  mobileBg: any;  

  constructor(
    private sanitizer: DomSanitizer,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private _redirectionService: RedirectionService
  ) {
    super();
    this.cards = [];
  }

  ngOnInit() {
    this.init();
  }

  private init() {
    if (this.data != undefined) {
      this.cards = this.data.map((item) => {
        item.FeaturedIcon = this.ApiUrl + item.FeaturedIcon;
        if(item.InfocardIcon !== "") {
          item.InfocardIcon = item.InfocardIcon.map(icon => {
            return this.ApiUrl + icon;
          }
          );
        }
        return item;
      });      
    }
  }

  public ManageContentNavigation(data: any) {
    let obj = new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj, this._router, this._activatedRoute);
  }

}
