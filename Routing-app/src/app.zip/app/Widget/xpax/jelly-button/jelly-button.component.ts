import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'cc-jelly-button',
  templateUrl: './jelly-button.component.html',
  styleUrls: ['./jelly-button.component.css']
})
export class JellyButtonComponent implements OnInit {
 
  @Input() public contentText: String;
  constructor() { }
  ngOnInit() {
  }

}
