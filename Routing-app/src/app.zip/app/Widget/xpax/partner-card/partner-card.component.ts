import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseComponent } from '../../../base.component';
import { PartnerCardService } from "./partner-card.service";
import { DomSanitizer } from '@angular/platform-browser';
import { ContentNavigation } from '../../../Model/contentnavigation.model';
import { ActivatedRoute, Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service';

@Component({
  selector: 'partner-card',
  templateUrl: './partner-card.component.html',
  styleUrls: ['./partner-card.component.css', '../../../../assets/css/bootstrap.min.css'],
  providers: [PartnerCardService]
})

export class PartnerCardComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  videoPatner: any;
  partnerTitle: any;
  desktopBg: any;
  mobileBg: any;
  public PartnerResponse = null;

  constructor(
    private sanitizer: DomSanitizer,
    private _service: PartnerCardService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private _redirectionService: RedirectionService
  ) {
    super();
    this.videoPatner = [];
  }

  ngOnInit() {
    this.init();
  }

  private init() {
    if (this.data && this.data.Api != undefined) {
      let apiUrl = "/" + this.data.Api + "?_format=hal_json";
      this._service.Find(this.data.Api.trim())
        .subscribe((response: any) => {
          //commneted for new response
          // const responseData = response.Items.map((item) => {
          //   item.PartnerImg = this.ApiUrl + item.PartnerImg;
          //   return item;
          // });          
          // while (responseData && responseData.length) {
          //   //spliting into a four items per row
          //   this.videoPatner.push(responseData.splice(0, 4));
          // }

          if(response.Items.length > 0){
            this.PartnerResponse = response.Items[0];
            if(this.PartnerResponse.DesktopImage!= undefined){
              this.desktopBg = this.ApiUrl + this.PartnerResponse.DesktopImage;
            }
            if(this.PartnerResponse.MobileImage!= undefined){
              this.mobileBg = this.ApiUrl + this.PartnerResponse.MobileImage;
            }
          }
          if(this.PartnerResponse.PartnerCardElement!= undefined){
            this.PartnerResponse.PartnerCardElement.forEach((item:any, index) => {
                    item.PartnerIcon.Icon = this.ApiUrl + item.PartnerIcon.Icon;                 
            });
          }
        }
        );
    }
  }

  public ManageContentNavigation(data: any) {
    let obj = new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj, this._router, this._activatedRoute);
  }

}