import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { BaseComponent } from '../../../base.component';
import { InfoCardTabsService } from "./info-card-tabs.service";
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'info-card-tabs',
  templateUrl: './info-card-tabs.component.html',
  styleUrls: ['./info-card-tabs.component.css', '../../../../assets/css/bootstrap.min.css'],
  providers: [InfoCardTabsService]
})
export class InfoCardTabsComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  cardTitle: any;
  subTitle: any;
  desktopBg: any;
  mobileBg: any;
  tabColor: any;
  infoCardResponse: any;

  constructor(
    private sanitizer: DomSanitizer,
    private _service: InfoCardTabsService
  ) {
    super();
  }

  ngOnInit() {
    this.init();
  }

  private init() {
    if (this.data && this.data.Api != undefined) {
      this.desktopBg = (this.data.Desktop != undefined) ? this.ApiUrl + this.data.Desktop.img : '';
      this.mobileBg = (this.data.Mobile != undefined) ? this.ApiUrl + this.data.Mobile.img : '';
      this.cardTitle = this.sanitizer.bypassSecurityTrustHtml(this.data.Title);
      this.subTitle = this.sanitizer.bypassSecurityTrustHtml(this.data.Subtitle);
      this.tabColor = this.data.TabColor;
      let apiUrl = "/" + this.data.Api + "?_format=hal_json";
      this._service.Find(this.data.Api.trim())
        .subscribe((response: any) => {
          this.infoCardResponse = response.Items;
        }
        );
    }
  }

}
