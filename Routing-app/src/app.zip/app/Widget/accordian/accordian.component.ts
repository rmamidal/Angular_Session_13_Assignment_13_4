import { Component, OnInit, Input,AfterViewInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {AccordianService} from './accordian.service';

@Component({
  selector: 'cc-accordian',
  templateUrl: './accordian.component.html',
  styleUrls: ['./accordian.component.css'],
  providers:[AccordianService]
})
export class AccordianComponent implements OnInit {
  @Input() data: any;
  public AccordionData = null;
  public TabNavigationData: any;
  public SelectedTab: string = ''; 
  public AccordionDataByTab: any; 
  public FaqHashContainer:string="";
  public IsAnchor:boolean= false;
  constructor(private _service:AccordianService,
    private _activatedRoute:ActivatedRoute, 
		private _router:Router
  ) { 
    this.TabNavigationData= [];
  }

  ngOnInit() {    
    this.Init();
    let currentUrl = this._router.routerState.snapshot.url.slice(1);    
    if (typeof window !== 'undefined') {
      if(localStorage.getItem("FaqAcnhor")!=null){
        this.FaqHashContainer = localStorage.getItem("FaqAcnhor");
        localStorage.removeItem("FaqAcnhor");
        this.IsAnchor = true;
      }
      else{
        this.FaqHashContainer = "";
        this.IsAnchor = false;
      }
    }   
    if(this.IsUrlContainsHash(currentUrl)){
      this.FaqHashContainer = this.SplitHashBasedUrl(currentUrl);
      this.IsAnchor = true;
    }
  }

  private Init() {
    if(this.data && this.data.Api != undefined){
      let apiUrl = "/" + this.data.Api + "?_format=hal_json";
      this._service.Find(apiUrl).subscribe(
        (response:any)=>{          
          if(response.data.length > 0){     
            this.AccordionData = response.data;    
            this.TabNavigationData = this.FindTabNavigationData(this.AccordionData);            
            if(!this.IsAnchor){
              this.SelectedTab = this.TabNavigationData[0].Term;
            }
            else{
              this.SelectedTab = this.FindActivatedTabOnLoadWhenAnchoring(this.AccordionData,this.FaqHashContainer);              
            }
            this.AccordionDataByTab = this.FindAccordionDataByActiveTab(this.AccordionData,this.SelectedTab);                         
            
            //handle scroll position when achoring            
            if(this.IsAnchor){
              this.ManageScollPosition();
            }
            //
          }
        });
    }
  }  
 
  private ManageScollPosition(){
    let that = this;    
    setTimeout(function() {                         
      if (typeof document !== 'undefined'){                                 
        let targetEl = document.querySelector(that.FaqHashContainer);
        var targetRect =  targetEl.getBoundingClientRect(); 
        if(targetRect!= null){
          if (typeof window !== 'undefined'){
            window.scrollTo(0,(targetRect.top-160));                
          }
        }
      }                                
    },10); 
  }
  private offset(el) {
    var rect = el.getBoundingClientRect(),
    scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
    scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return { top: rect.top + scrollTop, left: rect.left + scrollLeft }
  }
  public OnTabSelect(item,index){
    this.SelectedTab = item.Term;
    this.AccordionDataByTab = this.FindAccordionDataByActiveTab(this.AccordionData,this.SelectedTab);
  }
  private FindAccordionDataByActiveTab(accordionData:Array<any>,activeTab:string){
    return accordionData.filter((item:any)=>{
      return (item.Term==activeTab);
    });
  }
  private FindTabNavigationData(accordionData:Array<any>){
    let result = [];
    accordionData.filter((item:any)=>{
      if(!this.IsAlreadyExist(result,item.Term)){
        result.push({
          Term:item.Term,
          Title:item.Title
        });
      }      
    });
    return result;
  }
  private IsAlreadyExist(result:Array<any>,term:string):boolean{
    let data = result.filter((item:any)=>{
      return (item.Term==term);
    });

    if(data.length>0){
      return true;
    }
    else{
      return false;
    }
  }
  private FindActivatedTabOnLoadWhenAnchoring(accordionData:any,anchorInfo){
    let tab:string = "";
    accordionData.forEach((item) => {
      item.Items.forEach((itemInner:any) => {
          if(itemInner.faqHash==anchorInfo){
            tab = item.Term;
            return;
          }
      });      
    });    
    return tab;
  }
  //
  private IsUrlContainsHash(currentUrl){        
    let result:boolean = currentUrl.indexOf("#") > -1;
    return result;
  }
  private SplitHashBasedUrl(currentHashUrl){
    let splitResult="";
    if(currentHashUrl!=null)
    {
      let result = currentHashUrl.split('#');
      if(result.length>0){
        splitResult =  "#" + result[1];
      }
    }
    return splitResult;
}
}
