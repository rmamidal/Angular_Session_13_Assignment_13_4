import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseComponent} from '../../../base.component';
import {ContentNavigation} from '../../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../../Service/redirection.service';

@Component({
 selector: 'imagecard-overlay-component',
 templateUrl: './card-gallery-overlay.component.html',
 styleUrls: ['./card-gallery-overlay.component.css'],
 providers:[RedirectionService]  
})
export class ImageCardOverlayComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public OverlayData = null;
  public ImageCardOverlayClass = '';   
  constructor(private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService,
    private _router: Router) {
      super();          
  }
    ngOnInit() {
    this.Init();
    }


  private Init() {      
    if(this.data != undefined && this.data != null){
        this.OverlayData = this.data;
        
        //commenting for this realese as this might be required in
        //next realese
         if(this.OverlayData.length == 2 || this.OverlayData.length == 1){
           this.ImageCardOverlayClass = "is-col-tablet-p-6 is-col-tablet-l-3 is-flex";
         }
         else{
           this.ImageCardOverlayClass = "is-col-tablet-p-4 is-equal-height";
         }
        //this.ImageCardOverlayClass = "is-col-tablet-p-4 is-equal-height";
    }
  }

  public ManageContentNavigation(data:any){ 
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);
  }
  
}
    
 