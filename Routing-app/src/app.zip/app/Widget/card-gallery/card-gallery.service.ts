import {Injectable} from '@angular/core';
import {Http, RequestOptions, Headers} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../../base.service';
import {AppService} from '../../Service/app.service';

@Injectable()
export class CardGalleryService extends BaseService  {
    constructor(private _service:AppService){
        super();
    }

    public Find(apiURL:string):Observable<any[]>{  
        let url = "/" + apiURL.replace(/[+_]/g,'%2B');              
        let options = this.GenerateHeader();        
        return this._service
        .get(url)
        .map((response:any) => {            
            return response
        });        
    }

    public FindOverlayMockData(apiURL:string):any{        
        return {
            Items : [
                {
                    "BannerImage": "/sites/default/files/cms_content_images/banner-image/imageCardOverlay_560x600.jpg",
                    "BannerTitle": "image-card-overlay-title",
                    "BannerAlt": "image-card-overlay-alt-text",
                    "Title": "<p>IMAGE CARD OVERLAY 1</p>",
                    "Subtitle": "<p>IMAGE CARD OVERLAY Subtitle</p>",
                    "ButtonLink": "/node/91",
                    "ButtonText": "Add More",
                    "Category": "Contest"
                },        
                {
                    "BannerImage": "/sites/default/files/cms_content_images/banner-image/imageCardOverlay_560x600_0.jpg",
                    "BannerTitle": "image-card-overlay-2-title",
                    "BannerAlt": "image-card-overlay-2-alt-text",
                    "Title": "<p>image card overlay 2</p>",
                    "Subtitle": "<p>image card overlay 2 subtitle</p>",
                    "ButtonLink": "https://www.google.co.in",
                    "ButtonText": "Buy More",
                    "Category": "Games"
                },
                {
                    "BannerImage": "/sites/default/files/cms_content_images/banner-image/imageCardOverlay_560x600.jpg",
                    "BannerTitle": "image-card-overlay-title",
                    "BannerAlt": "image-card-overlay-alt-text",
                    "Title": "<p>IMAGE CARD OVERLAY 3</p>",
                    "Subtitle": "<p>IMAGE CARD OVERLAY Subtitle</p>",
                    "ButtonLink": "/node/91",
                    "ButtonText": "Add More",
                    "Category": "Humour"
                },        
                {
                    "BannerImage": "/sites/default/files/cms_content_images/banner-image/imageCardOverlay_560x600_0.jpg",
                    "BannerTitle": "image-card-overlay-2-title",
                    "BannerAlt": "image-card-overlay-2-alt-text",
                    "Title": "<p>image card overlay 4</p>",
                    "Subtitle": "<p>image card overlay 2 subtitle</p>",
                    "ButtonLink": "https://www.google.co.in",
                    "ButtonText": "Buy More",
                    "Category": "Don't know"
                },
                {
                    "BannerImage": "/sites/default/files/cms_content_images/banner-image/imageCardOverlay_560x600.jpg",
                    "BannerTitle": "image-card-overlay-title",
                    "BannerAlt": "image-card-overlay-alt-text",
                    "Title": "<p>IMAGE CARD OVERLAY 5</p>",
                    "Subtitle": "<p>IMAGE CARD OVERLAY Subtitle</p>",
                    "ButtonLink": "/node/91",
                    "ButtonText": "Add More",
                    "Category": "Fine"
                },        
                {
                    "BannerImage": "/sites/default/files/cms_content_images/banner-image/imageCardOverlay_560x600_0.jpg",
                    "BannerTitle": "image-card-overlay-2-title",
                    "BannerAlt": "image-card-overlay-2-alt-text",
                    "Title": "<p>image card overlay  6</p>",
                    "Subtitle": "<p>image card overlay 2 subtitle</p>",
                    "ButtonLink": "https://www.google.co.in",
                    "ButtonText": "Buy More",
                    "Category": "At last"
                }
                        
            ],
            Status: "200",
            StatusMessage: "SUCCESS"
        }
        
    }

   
}