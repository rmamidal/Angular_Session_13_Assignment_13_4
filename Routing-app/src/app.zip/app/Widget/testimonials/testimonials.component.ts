import { Component, OnInit, ViewContainerRef, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { TestimonialsService} from "./testimonials.component.service";
import { AppWidgetComponent } from '../../Model/app.widget.component';
import { BaseComponent } from '../../base.component';
import { ContentNavigation } from '../../Model/contentnavigation.model';
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../Service/redirection.service';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.css'],
  providers: [ RedirectionService, TestimonialsService ]
})
export class TestimonialsComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public TestimonialsResponse = null;
  public deskImage = null;  

  
  constructor(private _TestimonialsService:TestimonialsService,public viewContainerRef: ViewContainerRef,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) {
      super();    
  }
 
  ngOnInit() {
    this.Init();
  }

  private Init() {  
    if(this.data && this.data.Api != undefined){           
      let url = "/" + this.data.Api + "?_format=hal_json";

      this._TestimonialsService.Find(url).subscribe(
      (response:any)=>{        
        this.TestimonialsResponse=response.Items[0];
      });
    }
  }
  public ManageContentNavigation(data:any){
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);  
  }
}
