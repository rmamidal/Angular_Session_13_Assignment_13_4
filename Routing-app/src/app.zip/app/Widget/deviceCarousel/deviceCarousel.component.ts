import { Component,OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {deviceCarouselService} from "./deviceCarousel.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'deviceCarousel-component',
  templateUrl: './deviceCarousel.component.html',
  styleUrls: [ './deviceCarousel.component.css' ],
  providers:[deviceCarouselService,RedirectionService]
})


export class deviceCarouselComponent extends BaseComponent implements AppWidgetComponent   {
  @Input() data: any;
  public deviceCarouselResponse = null;
  public deviceCarouselAPIResponse = null;
  
  constructor(private deviceCarouselService: deviceCarouselService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService
  ){
    super();
  }

  ngOnInit(){
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api !=undefined){
      this.deviceCarouselResponse = this.data;
      let apiUrl:string = "/" + this.data.Api + "?_format=hal_json";      
      this.deviceCarouselService.Find(apiUrl.trim()).subscribe(      
          (response: any)=>{               
              this.deviceCarouselAPIResponse = response.Items; 
              this.deviceCarouselAPIResponse.forEach((item:any, index) => {
                  item.BannerImage = this.ApiUrl + item.BannerImage;                 
              });
          });
    }
  }
  public ManageContentNavigation(data:any){              
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
}