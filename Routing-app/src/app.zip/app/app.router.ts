import {ModuleWithProviders} from '@angular/core';
import {Routes,RouterModule,Router} from '@angular/router';
import {HomeComponent} from './Home/home.component';

// EStore.
import { DeviceHomeComponent } from './Store/device/device-home/device-home.component';
import { DeviceCatalogueComponent } from './Store/device/device-catalogue/device-catalogue.component';
import { PlanHomeComponent } from './Store/plan/plan-home/plan-home.component';
import { PlanDetailsComponent } from './Store/plan/plan-details/plan-details.component';
import { PlanComparisonComponent } from './Store/plan/plan-comparison/plan-comparison.component';
import { PlanTableComparisonComponent } from './Widget/StoreWidgets/plan-table-comparison/plan-table-comparison.component'
import { CartHomeComponent } from './Store/cart/cart-home/cart-home.component';

export const router:Routes =[
    {path: 'personal/devices', component:DeviceHomeComponent},
    {path: 'personal/postpaid', component:PlanHomeComponent},
    {path: 'store/plans/:planId', component:PlanDetailsComponent},
    {path: 'store/plan/comparison', component:PlanComparisonComponent},
    {path: 'store/devices', component:DeviceCatalogueComponent},
    {path: 'store/cart', component:CartHomeComponent},
    {path:"",pathMatch:"full",component:HomeComponent,data:{"EndPoint":""}},
	{path:"**",component:HomeComponent,data:{"EndPoint":"","Star":"*"}},
];

//export const routes:ModuleWithProviders = RouterModule.forRoot(router);
