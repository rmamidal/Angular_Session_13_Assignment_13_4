import { CartItem } from './cart-item.model';

export class Cart {
    public items: CartItem[] = new Array<CartItem>();
    public grossTotal: number = 0;
    public itemsTotal: number = 0;

    public setCart(cart:Cart) {
        this.items = cart.items;
        this.grossTotal = cart.grossTotal;
        this.itemsTotal = cart.itemsTotal;
    }
}
