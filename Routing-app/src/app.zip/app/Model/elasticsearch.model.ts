export class ElasticSearchRequestModel{
    public PageSize:number=10;
    public SearchTerm:string=null;
    public PageIndex:number=0;
    public PrettyScript:string="true";    
    constructor(){  
    }    
}