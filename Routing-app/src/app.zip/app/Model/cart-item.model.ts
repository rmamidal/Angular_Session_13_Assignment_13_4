export class CartItem {
    public sku: string;
    public quantity: number = 0;
    public price: number = 300;
    public itemTotal: number = 0;
}
