import { Component } from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { AfterViewInit, Renderer, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import {AppService} from "./Service/app.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'], 
})
export class AppComponent implements AfterViewInit{
  title = 'app';
  componetData: any;
  RoutesData: any;
  isNotificationOpen:any;

  // constructor(private routesservice: RoutesService){   
    constructor(@Inject(DOCUMENT) private document: any, private renderer: Renderer,private _appService: AppService) {
    // this.routesInit();
  }
  onNotificationChange( isNotificationOpen) { 
    this.isNotificationOpen = isNotificationOpen;
  }
  ngAfterViewInit(): void {  
    this._appService.get('/api/config?_format=hal_json').subscribe((data:any)=>{
      let footerScript = data.GlobalSettings[1].value.substring(data.GlobalSettings[1].value.indexOf(">")+1,data.GlobalSettings[1].value.lastIndexOf("<"));
      let headerScript = data.GlobalSettings[0].value.substring(data.GlobalSettings[0].value.lastIndexOf("src=")+5,data.GlobalSettings[0].value.lastIndexOf("></script>")-1);
      const headerElem = this.renderer.createElement(this.document.head, 'script');
      const footerElem = this.renderer.createElement(this.document.body, 'script');
      this.renderer.setElementProperty(headerElem, 'src',headerScript);
      this.renderer.setElementProperty(footerElem,'type','text/javascript');
      this.renderer.setElementAttribute(footerElem,'text',footerScript);

    });
  }
  // private routesInit() {
  //   this.routesservice.Find().subscribe((data)=>{
  //     this.RoutesData = data;
  //     console.log(this.RoutesData); 
  // });
  // }
}
