import { Component, OnInit, HostListener, Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { AppWidgetComponent } from '../../../Model/app.widget.component';
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute, Router } from '@angular/router';
import { QuickLinksService } from "./quick-links.service";
import {RedirectionService} from '../../../Service/redirection.service'

@Component({
  selector: 'quick-links',
  templateUrl: './quick-links.component.html',
  styleUrls: ['./quick-links.component.css'],
  providers: [QuickLinksService, RedirectionService]
})

export class QuickLinksComponent extends BaseComponent implements OnInit {
  public quickLinksItems=[];
  public flag: boolean;
  public isActive: boolean;
  public overlayStyle: any;
  public fatime: boolean;
  public faplus: boolean;
  public showClass: boolean;
  public mbQlinks: any;
  public showcircle: boolean;
  public winWidth: number;
  public idleTime: any;
  public mbQucikbtnImg: any;
  public mbImgObj = { open: '', close: '' };
  public QuckLinksResponse = null;
 
   
  @HostListener('window:scroll', ['$event'])
  onWindowScroll($event) {
    if(this.fatime != true){
      this.scroll();
    }
  }

  @HostListener('window:mousemove', ['$event'])
  onMousemove($event) {
    this.resetTimer();
  }

  constructor(
    private _router: Router, 
    private _activatedRoute: ActivatedRoute, 
    private _service: QuickLinksService, 
    private _redirectionService:RedirectionService
  ){
    super();
    this.mbQucikbtnImg = 'url(' + this.mbImgObj.open + ')';
    this.flag = true;
    this.isActive = false;
    this.faplus = true;
    this.fatime = false;
    this.showClass = false;
    this.overlayStyle = {
      'visibility': 'hidden'
    };
    if (typeof window !== 'undefined'){
      this.winWidth = window.innerWidth;
      if (this.winWidth <= 767) {
        this.showcircle = true;
      } else {
        this.showcircle = false;
      }
    }
  }

  ngOnInit() {
    if (typeof window !== 'undefined'){
      window.onload = this.resetTimer;
      document.onkeypress = this.resetTimer;
    }
    this.Init();
  }

private Init() {
    this._service.findQuickLinks().subscribe((data) => {
      this.QuckLinksResponse = data  && data['data'] && data['data']['Items'] ? data['data']['Items'] : null;
      this.mbImgObj.open = this.ApiUrl + this.QuckLinksResponse.mobile_plus_file_path;
      this.mbImgObj.close = this.ApiUrl + this.QuckLinksResponse.mobile_minus_file_path;
      this.faplus = true;
      this.fatime = false;
      this.showClass = false;
      this.mbQucikbtnImg = 'url(' + this.mbImgObj.open + ')';
      this.overlayStyle = {
        'visibility': 'hidden'
      }
    });
  }
  getUrl(index: number) {
    return 'url(' + this.ApiUrl + this.QuckLinksResponse['quicklink_collection'][index].quicklink_icon + ')';
  }

  public clickQickLinks(event) {
    
    if (event.target.classList.contains('mb-close')) {
      this.faplus = true;
      this.fatime = false;
      this.showClass = false;
      this.mbQucikbtnImg = 'url(' + this.mbImgObj.open + ')';
      this.overlayStyle = {
        'visibility': 'hidden'
      }
    } else {
      this.faplus = false;
      this.fatime = true;
      this.showClass = true;
      this.mbQucikbtnImg = 'url(' + this.mbImgObj.close + ')';
      this.overlayStyle = {
        'visibility': 'visible'
      }
    }
  }

  public overlayClick() {
    this.faplus = true;
    this.fatime = false;
    this.showClass = false;
    this.mbQucikbtnImg = 'url(' + this.mbImgObj.open + ')';
    this.overlayStyle = {
      'visibility': 'hidden'
    }
  }
   public scroll() {
    this.faplus = true;
    this.fatime = false;
    if (typeof document !== 'undefined'){
      let mobileQuickLink =  document.getElementById("mbQicklks");
      if(mobileQuickLink != null){
        mobileQuickLink.style.visibility = "hidden";
      }
    }
    this.showClass = false;
    this.mbQucikbtnImg = 'url(' + this.mbImgObj.open + ')';
    this.overlayStyle = {
      'visibility': 'hidden'
    };
    this.resetTimer();
  }

  public showQuickLnksBnt() {
    if (typeof window !== 'undefined'){
      if (window.innerWidth <= 767) {
      let mobileQuickLink =  document.getElementById("mbQicklks");
        if(mobileQuickLink != null){
          mobileQuickLink.style.visibility = "visible";
        }
      }
    }
  }

  public resetTimer() {
    clearTimeout(this.idleTime);
    this.idleTime = setTimeout(this.showQuickLnksBnt, 5000);
  }

  
}   
