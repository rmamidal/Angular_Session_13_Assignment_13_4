import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { CartService } from '../../../Service/cart.service';
import { BaseComponent } from '../../../base.component';
import { ContentNavigation } from '../../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../../Service/redirection.service'
import  {AppService} from '../../../Service/app.service';

@Component({
  selector: 'app-cart-home',
  templateUrl: './cart-home.component.html',
  styleUrls: ['./cart-home.component.css'],
  providers:[RedirectionService,CartService]
})
export class CartHomeComponent extends BaseComponent implements OnInit  {
    public cart = null;
    constructor(
        private _service:AppService,
		private cartService:CartService,
		private _router:Router,
		private _activatedRoute:ActivatedRoute,
		private _redirectionService:RedirectionService) { 
		super();
    }
    
    ngOnInit() {
        this.cart = this.cartService.retrieveCart();
    }

    removeCartItem(product:any) {
        this.cartService.removeProductFromCart(product);
        this.cart = this.cartService.retrieveCart();
    }
}
