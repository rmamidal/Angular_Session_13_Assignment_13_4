import { Component, OnInit } from '@angular/core';
import { CompareProductService } from '../../../Service/compareproduct.service';

@Component({
  selector: 'app-device-catalogue',
  templateUrl: './device-catalogue.component.html',
  styleUrls: ['./device-catalogue.component.css'],
  providers:[CompareProductService]
})
export class DeviceCatalogueComponent implements OnInit {
  public productsToCompare = null;
  constructor(private compProductService: CompareProductService) { }

  ngOnInit() {
    this.Init();
  }

  Init() {
		this.productsToCompare = this.compProductService.retrieveProduct();
  }

  addCompareItems(item:any) {
    this.compProductService.addProductToCompare(item);
    this.productsToCompare = this.compProductService.retrieveProduct();
  }

  removeCompareProduct(product:any) {
    this.compProductService.removeProductFromCompare(product);
    this.productsToCompare = this.compProductService.retrieveProduct();
  }
  
  removeAllCompareProducts() {
    this.compProductService.removeAllProductFromCompare();
    this.productsToCompare = this.compProductService.retrieveProduct();
  }
}
