import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceCatalogueComponent } from './device-catalogue.component';

describe('DeviceCatalogueComponent', () => {
  let component: DeviceCatalogueComponent;
  let fixture: ComponentFixture<DeviceCatalogueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceCatalogueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceCatalogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
