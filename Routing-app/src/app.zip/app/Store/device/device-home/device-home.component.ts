import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-home',
  templateUrl: './device-home.component.html',
  styleUrls: ['./device-home.component.css']
})
export class DeviceHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
