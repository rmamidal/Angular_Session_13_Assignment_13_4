import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan',
  templateUrl: './plan-home.component.html',
  styleUrls: ['./plan-home.component.css']
})
export class PlanHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
